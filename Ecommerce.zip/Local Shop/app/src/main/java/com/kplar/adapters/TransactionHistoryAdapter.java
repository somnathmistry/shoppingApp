package com.kplar.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.kplar.R;
import com.kplar.models.kplarWalletPackage.Tansactionhistory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TransactionHistoryAdapter extends RecyclerView.Adapter<TransactionHistoryAdapter.MyViewHolder> {

    List<Tansactionhistory> tansactionhistoryList;
    Context context;

    public TransactionHistoryAdapter(List<Tansactionhistory> tansactionhistoryList, Context context) {
        this.tansactionhistoryList = tansactionhistoryList;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction_history_layout, parent, false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {


       /* SimpleDateFormat df = new SimpleDateFormat("MM/DD/YYYY hh:mm:ss") ;
        try {
            df.parse(tansactionhistoryList.get(position).getDate());
        } catch (ParseException e) {
            e.printStackTrace();
        }*/
        holder.date.setText(tansactionhistoryList.get(position).getDate());
        holder.amount.setText(tansactionhistoryList.get(position).getAmount());
        holder.txnId.setText(tansactionhistoryList.get(position).getTransactionid());

        String type = tansactionhistoryList.get(position).getType();

        if (type.equals("0")) {
            holder.indicator.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.circleshape_in_green));

        } else if (type.equals("1")) {
            holder.indicator.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.circleshape_in_red));
        }


    }

    @Override
    public int getItemCount() {
        return tansactionhistoryList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView date, amount, txnId;
        ImageView indicator;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            date = itemView.findViewById(R.id.date);
            amount = itemView.findViewById(R.id.amount);
            txnId = itemView.findViewById(R.id.transId);
            indicator = itemView.findViewById(R.id.indicator);
        }
    }
}
