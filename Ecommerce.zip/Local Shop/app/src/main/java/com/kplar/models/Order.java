package com.kplar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Order {
    @SerializedName("userName")
    @Expose
    String userName;

    @SerializedName("product_id")
    @Expose
    String product_id;

    @SerializedName("qty")
    @Expose
    String qty;

    @SerializedName("amount")
    @Expose
    String amount;

    @SerializedName("transactionId")
    @Expose
    String transactionId;

    @SerializedName("paymentMethod")
    @Expose
    String paymentMethod;

    @SerializedName("order_id")
    @Expose
    String order_id;

    public String getUserName() {
        return userName;
    }

    public String getProduct_id() {
        return product_id;
    }

    public String getQty() {
        return qty;
    }

    public String getAmount() {
        return amount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getOrder_id() {
        return order_id;
    }
}
