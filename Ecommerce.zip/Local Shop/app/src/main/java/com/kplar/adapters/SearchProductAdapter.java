package com.kplar.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kplar.R;
import com.kplar.activities.ProductDetailsActivity;
import com.kplar.models.SearchProduct;
import com.kplar.models.SearchProductData;

import java.util.List;

public class SearchProductAdapter extends RecyclerView.Adapter<SearchProductAdapter.MySearchViewHolder> {
    List<SearchProductData> list;
    Context context;

    public SearchProductAdapter(List<SearchProductData> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public MySearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_items, parent, false);
        return new MySearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MySearchViewHolder holder, int position) {
        double mrps, discountPers, discountPrices;

        mrps = Double.parseDouble(list.get(position).getProductPrice());
        discountPers = Double.parseDouble(list.get(position).getDiscount());

        discountPrices = mrps - ((discountPers / 100) * mrps);
        Glide.with(context).load(list.get(position).getProductImage()).into(holder.proImgs);
        holder.productNames.setText(list.get(position).getProductName());
        holder.proDescs.setText(list.get(position).getProductDescripition());
        holder.mrps.setText(list.get(position).getProductPrice());
        holder.productDiscountPercents.setText(String.format("%s%% OFF", list.get(position).getDiscount()));

        holder.proDiscountPrices.setText(String.format("%s", discountPrices));

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MySearchViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView starreds, proImgs;
        TextView productNames, proDescs, mrps, proDiscountPrices, productDiscountPercents;

        public MySearchViewHolder(@NonNull View itemView) {
            super(itemView);

            itemView.setOnClickListener(this);
            starreds = itemView.findViewById(R.id.starred_imgId);
            proImgs = itemView.findViewById(R.id.product_imgId);
            productNames = itemView.findViewById(R.id.productName);
            proDescs = itemView.findViewById(R.id.productDescId);
            proDiscountPrices = itemView.findViewById(R.id.product_dicountPriceId);
            mrps = itemView.findViewById(R.id.mrpId);
            productDiscountPercents = itemView.findViewById(R.id.discountPercentId);
        }

        @Override
        public void onClick(View v) {
            Intent intent = new Intent(context, ProductDetailsActivity.class);
            intent.putExtra("productId", list.get(getAdapterPosition()).getProductId());
            intent.putExtra("productName", list.get(getAdapterPosition()).getProductName());
            context.startActivity(intent);
        }
    }
}
