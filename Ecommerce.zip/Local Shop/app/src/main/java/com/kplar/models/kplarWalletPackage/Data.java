package com.kplar.models.kplarWalletPackage;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Data {
    @Expose
    @SerializedName("tansactionHistory")
    private List<Tansactionhistory> tansactionhistory;
    @Expose
    @SerializedName("currentMonthTransactionAmount")
    private int currentmonthtransactionamount;
    @Expose
    @SerializedName("totalWalletBalance")
    private String totalwalletbalance;

    public List<Tansactionhistory> getTansactionhistory() {
        return tansactionhistory;
    }

    public void setTansactionhistory(List<Tansactionhistory> tansactionhistory) {
        this.tansactionhistory = tansactionhistory;
    }

    public int getCurrentmonthtransactionamount() {
        return currentmonthtransactionamount;
    }

    public void setCurrentmonthtransactionamount(int currentmonthtransactionamount) {
        this.currentmonthtransactionamount = currentmonthtransactionamount;
    }

    public String getTotalwalletbalance() {
        return totalwalletbalance;
    }

    public void setTotalwalletbalance(String totalwalletbalance) {
        this.totalwalletbalance = totalwalletbalance;
    }
}
