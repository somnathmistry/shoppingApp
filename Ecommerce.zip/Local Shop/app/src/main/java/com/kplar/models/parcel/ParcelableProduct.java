package com.kplar.models.parcel;

import android.os.Parcel;
import android.os.Parcelable;

public class ParcelableProduct implements Parcelable {
    private String productName;
    private String productPic;
    private double mrp;
    private double sellingPrice;
    private double discount;
    private int qty;

    public ParcelableProduct(String productName, String productPic, double mrp, double sellingPrice, double productDiscount, int qty) {
        this.productName = productName;
        this.productPic = productPic;
        this.mrp = mrp;
        this.sellingPrice = sellingPrice;
        this.discount = productDiscount;
        this.qty = qty;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPic() {
        return productPic;
    }

    public void setProductPic(String productPic) {
        this.productPic = productPic;
    }

    public double getMrp() {
        return mrp;
    }

    public void setMrp(double mrp) {
        this.mrp = mrp;
    }

    public double getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(double sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public static Creator<ParcelableProduct> getCREATOR() {
        return CREATOR;
    }

    public ParcelableProduct() {
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.productName);
        dest.writeString(this.productPic);
        dest.writeDouble(this.mrp);
        dest.writeDouble(this.sellingPrice);
        dest.writeDouble(this.discount);
        dest.writeInt(this.qty);
    }

    private ParcelableProduct(Parcel in) {
        this.productName = in.readString();
        this.productPic = in.readString();
        this.mrp = in.readDouble();
        this.sellingPrice = in.readDouble();
        this.discount = in.readDouble();
        this.qty = in.readInt();
    }

    public static final Parcelable.Creator<ParcelableProduct> CREATOR = new Parcelable.Creator<ParcelableProduct>() {
        @Override
        public ParcelableProduct createFromParcel(Parcel source) {
            return new ParcelableProduct(source);
        }

        @Override
        public ParcelableProduct[] newArray(int size) {
            return new ParcelableProduct[size];
        }
    };
}
