package com.kplar.fragments;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kplar.R;

public class ViewAllActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all);
    }
}