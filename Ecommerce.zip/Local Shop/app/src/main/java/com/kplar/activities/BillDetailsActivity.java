package com.kplar.activities;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.kplar.R;
import com.kplar.fragments.BillDetailsFragment;
import com.kplar.fragments.CouponVerifierDialogFragment;
import com.kplar.utilities.MyPrefernces;

import java.util.Objects;

public class BillDetailsActivity extends AppCompatActivity implements CouponVerifierDialogFragment.OnCouponVerifiedListener {


    Bundle bundle;
    Toolbar toolbar;
    BillDetailsFragment billDetailsFragment;
    FragmentManager fragmentManager;
    MyPrefernces myPrefernces;
    String userName;
    String price;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill_details);

        toolbar = findViewById(R.id.bill_details_tool_bar);
        price = getIntent().getStringExtra("price");
//        textView = findViewById(R.id.total_amount_tv);
//        textView.setText(price);


        toolbar.setTitle("Product(s) and Bill");
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(getResources().getColor(R.color.white_color));
        toolbar.setTitleTextAppearance(this, R.style.myFont);

        if (toolbar != null) {
            Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

        }

        myPrefernces = new MyPrefernces(this);
        userName = myPrefernces.readUserName();


        Bundle bundle = new Bundle();
        bundle.putString("src", getIntent().getStringExtra("source"));
        bundle.putParcelable("product", getIntent().getParcelableExtra("product"));

        billDetailsFragment = new BillDetailsFragment();
        billDetailsFragment.setArguments(bundle);
        setFragment(billDetailsFragment);


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.product_and_bill_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.help_menu_item:

                return true;


            case R.id.category:


            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void setFragment(Fragment fragment) {
        if (fragment != null) {
            fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.bill_details_container, fragment);
            //fragmentTransaction.addToBackStack("OP");
            fragmentTransaction.commit();
        }

    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }


    @Override
    public void couponData(String percentValue, String upToValue, boolean isSuccess) {
        if (isSuccess) {

            bundle = new Bundle();
            bundle.putString("percentValue", percentValue);
            bundle.putString("upToValue", upToValue);
            bundle.putBoolean("isSuccess", isSuccess);
            if (billDetailsFragment != null) {
                billDetailsFragment.getCouponDataFromContext(percentValue, upToValue, isSuccess);
            }
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {

        if (bundle != null) {

            outState = this.bundle;
        }
        super.onSaveInstanceState(outState);

    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Toast.makeText(this, "onRestoreInstanceState", Toast.LENGTH_SHORT).show();
        String percentValue = (String) savedInstanceState.get("percentValue");
        String upToValue = (String) savedInstanceState.get("upToValue");
        boolean isSuccess = savedInstanceState.getBoolean("isSuccess");
        if (billDetailsFragment != null) {

            billDetailsFragment.getCouponDataFromContext(percentValue, upToValue, isSuccess);
        }

    }
}
