package com.kplar.activities;

import android.content.Context;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.kplar.R;
import com.kplar.fragments.GiftCardFragment;
import com.kplar.fragments.ReceiveGiftCardFragment;
import com.kplar.fragments.SendGiftCardFragment;

import java.util.Objects;

public class GiftCardActivity extends AppCompatActivity implements GiftCardFragment.OnFragmentChangeListener {

    FragmentManager fragmentManager;
    GiftCardFragment giftCardFragment;
    SendGiftCardFragment sendGiftCardFragment;
    ReceiveGiftCardFragment receiveGiftCardFragment;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gift_card_actvity);

        toolbar = findViewById(R.id.gift_card_toolbar);
        toolbar.setTitle("Gift Card");
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(getResources().getColor(R.color.white_color));
        toolbar.setTitleTextAppearance(this, R.style.myFont);


        if (toolbar != null) {
            Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }


    private void setFragment(Fragment fragment, String fgrName) {
        if (fragment != null) {
            fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container, fragment, fgrName);
            if (!fgrName.equals("giftCardFragment"))
                fragmentTransaction.addToBackStack("OP" + fgrName);

            fragmentTransaction.commit();
            //Toast.makeText(this, "" + fgrName, Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        giftCardFragment = new GiftCardFragment();
        setFragment(giftCardFragment, "giftCardFragment");

        sendGiftCardFragment = new SendGiftCardFragment();
        receiveGiftCardFragment = new ReceiveGiftCardFragment();
    }

    @Override
    public void setOnFragment(String fgrName) {

        if (fgrName.equals("send Gift Card Fragment")) {
            setFragment(sendGiftCardFragment, "send");
            toolbar.setTitle("Send Gift Card");
        } else if (fgrName.equals("receive Gift Card Fragment")) {
            setFragment(receiveGiftCardFragment, "receive");
            toolbar.setTitle("Receive Gift Card");

        }

    }

    @Override
    public void onAmountSendListener(String giftAmount) {
        Bundle bundle = new Bundle();
        bundle.putString("amount", giftAmount);
        setFragment(sendGiftCardFragment, "send");
        toolbar.setTitle("Send Gift Card");
        sendGiftCardFragment.setArguments(bundle);
       // Toast.makeText(this, "" + giftAmount, Toast.LENGTH_SHORT).show();


    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public void onBackPressed() {
        //super.onBackPressed();

        if (sendGiftCardFragment != null && sendGiftCardFragment.isVisible()) {
            super.onBackPressed();
            toolbar.setTitle("Gift Card");
        } else if (receiveGiftCardFragment != null && receiveGiftCardFragment.isVisible()) {
            super.onBackPressed();
            toolbar.setTitle("Gift Card");
        } else {
            finish();
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus() != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            assert imm != null;
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(ev);
    }
}
