package com.kplar.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.kplar.R;
import com.kplar.SuccessfulActivity;
import com.kplar.models.Order;
import com.kplar.models.RazorPay;
import com.kplar.models.parcel.ParcelableProduct;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;
import com.razorpay.Checkout;
import com.razorpay.PaymentData;
import com.razorpay.PaymentResultListener;
import com.razorpay.PaymentResultWithDataListener;

import org.json.JSONObject;

import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Query;

public class RozerPayActivity extends AppCompatActivity implements PaymentResultWithDataListener {

    public static final String TAG = RozerPayActivity.class.getSimpleName();
    ParcelableProduct parcelableProduct;
    int price = 100 * 100;
    //private  String stringPrice = "2000";
    ParcelableProduct parcel;
    String Userid = "sr1234";
    ApiInterface apiInterface, apiInterfaceOrder;
    String id;
    private TextView textView;
    Double totalPrice;

//    String userName = "Userid";
//    String productId = "productId", qty = "Quantity", amount = "Amount",
//    transaction = "Transaction Id", payment = "Payment";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rozer_pay);
        Checkout.preload(getApplicationContext());
        textView = findViewById(R.id.textId);

        textView.setText(id);

        parcelableProduct = new ParcelableProduct();
        Locale locale = new Locale("en", "IN");
        parcel = getIntent().getParcelableExtra("amount");
        totalPrice = parcel.getSellingPrice();

        //Toast.makeText(this, "TP " + totalPrice, Toast.LENGTH_SHORT).show();

        uploadUserDetails(Userid, totalPrice * 100.0 + "");


    }

    private void uploadUserDetails(String userId, String price) {
        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<RazorPay> razorPayCall = apiInterface.uploadPaymentDetails(userId, price);
        razorPayCall.enqueue(new Callback<RazorPay>() {
            @Override
            public void onResponse(Call<RazorPay> call, Response<RazorPay> response) {

                //String s = response.body().getAmount();
                id = response.body().getOrderId();
                startPayment(id);
                Log.i(TAG, "onResponse: " + id);
                Toast.makeText(RozerPayActivity.this, "Upload Method calling" + id, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<RazorPay> call, Throwable t) {

            }
        });

    }

    public void startPayment(String orderId) {
        /**
         * Instantiate Checkout
         */
        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_0sq0DmH1mb4Znp");
        /**
         * Set your logo here
         */
        //checkout.setImage(R.drawable.logo);
        /**
         * Reference to current activity
         */
        final Activity activity = this;

        /**
         * Pass your payment options to the Razorpay Checkout as a JSONObject
         */
        try {
            JSONObject options = new JSONObject();

            /**
             * Merchant Name
             * eg: ACME Corp || HasGeek etc.
             */
            options.put("name", "Somnath");

            /**
             * Description can be anything
             * eg: Reference No. #123123 - This order number is passed by you for your internal reference. This is not the `razorpay_order_id`.
             *     Invoice Payment
             *     etc.
             */

            options.put("description", "My order Description");
            //options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png");

            options.put("order_id", id);
            Log.i(TAG, "startPayment: Order Id " + orderId);

            options.put("currency", "INR");
            options.put("amount", totalPrice * 100.0);


            checkout.open(activity, options);

        } catch (Exception e) {
            Log.e(TAG, "Error in starting Razorpay Checkout", e);
        }

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        startActivity(intent);
        super.onBackPressed();

    }

    @Override
    public void onPaymentSuccess(String s, PaymentData paymentData) {
        try {
            Log.i(TAG, " Inside the onPaymentSuccess");
            createOrder(paymentData.getPaymentId(), paymentData.getOrderId());
            Intent intent = new Intent(getApplicationContext(), SuccessfulActivity.class);
            startActivity(intent);
            finish();
        } catch (Exception e) {
            Log.i(TAG, "onPaymentSuccess: " + e.getMessage());
        }
    }

    private void createOrder(String paymentId, String productId) {
        Toast.makeText(this, "Inside the Order", Toast.LENGTH_LONG).show();
//        Log.i(TAG, "getOrder: Inside the Order" + paymentId + "  " + orderId + "  " + qty + "  "
//                + amount + "  " + transaction + "  " + payment + "  " + userName);

        MyPrefernces myPreferncesOrder = new MyPrefernces(this);
        String username =  myPreferncesOrder.readUserName();
        String qty = String.valueOf(parcel.getQty());
        String amount = String.valueOf((parcelableProduct.getSellingPrice()));
        String paymentMethod = "Razorpay";

        Log.i(TAG, "Real value: " + username + " " + productId + " " + parcel.getQty()+ " " + totalPrice * 100.0 + "" + " "+ paymentId +""+ "Razorpay"+" "+productId );
/*
        @Query("userName") String userName,
        @Query("product_id") String product_id,
        @Query("qty") String qty,
        @Query("amount") String amount,
        @Query("transactionId") String transactionId,
        @Query("paymentMethod") String paymentMethod,
        @Query("order_id") String order_id

 */
        apiInterfaceOrder = ApiClient.getApiClient().create(ApiInterface.class);
        Call<Order> orderCall = apiInterfaceOrder.uploadOrder(username, productId, qty, totalPrice * 100.0 + "", paymentId, paymentMethod, productId);
        orderCall.enqueue(new Callback<Order>() {
            @Override
            public void onResponse(Call<Order> call, Response<Order> response) {
                Toast.makeText(RozerPayActivity.this, "Order Placed", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<Order> call, Throwable t) {

            }
        });
    }

    @Override
    public void onPaymentError(int i, String s, PaymentData paymentData) {

    }
}