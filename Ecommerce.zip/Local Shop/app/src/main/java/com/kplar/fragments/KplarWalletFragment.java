package com.kplar.fragments;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.kplar.R;
import com.kplar.adapters.TransactionHistoryAdapter;
import com.kplar.models.kplarWalletPackage.KplarWallet;
import com.kplar.models.kplarWalletPackage.Tansactionhistory;
import com.kplar.models.paytmPackage.PaytmChecksum;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class KplarWalletFragment extends Fragment {
    private BottomSheetBehavior sheetBehavior;
    private ConstraintLayout addMoneyByBs;
    private ImageButton addMoneyBtn;
    private EditText addMoneyEt;
    private double addedAmount;
    private Button proceedToAddBtn, refreshBtn;
    private TextView errorTv, balanceTv;
    private ApiInterface apiInterface;
    private MyPrefernces myPrefernces;
    private Context context;
    private String userName;
    private double walletBal;
    private int currentMonthTxnAmount;
    private ConstraintLayout txnHistoryContainer;
    private RecyclerView txnHistoryRv;
    private TransactionHistoryAdapter transactionHistoryAdapter;
    private List<Tansactionhistory> tansactionhistoryList;
    ProgressBar walletProgressBar;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_kplar_wallet, container, false);

        addMoneyByBs = view.findViewById(R.id.bs_add_money);
        addMoneyBtn = view.findViewById(R.id.add_money_ib);
        addMoneyEt = view.findViewById(R.id.add_money_et);
        proceedToAddBtn = view.findViewById(R.id.proceed_to_add_btn);
        txnHistoryRv = view.findViewById(R.id.txn_history_rv);
        txnHistoryContainer = view.findViewById(R.id.txn_history_container);
        errorTv = view.findViewById(R.id.error_tv);
        view.findViewById(R.id.txn_history_container);
        view.findViewById(R.id.txn_history_rv);
        balanceTv = view.findViewById(R.id.balance_tv);
        refreshBtn = view.findViewById(R.id.refresh_btn);

        walletProgressBar = view.findViewById(R.id.wallet_progress);

        txnHistoryRv.setLayoutManager(new LinearLayoutManager(getActivity()));
        txnHistoryRv.setHasFixedSize(true);

        myPrefernces = new MyPrefernces(context);
        userName = myPrefernces.readUserName();


        sheetBehavior = BottomSheetBehavior.from(addMoneyByBs);

        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onStart() {
        super.onStart();

        viewWalletDetails();

        addMoneyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                toggleBottomSheet();

            }
        });


        addMoneyEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String regex = "^[1-9][0-9]*(\\.[0-9]{1,2})?$";
                try {
                    double tempAmount = Double.parseDouble(s.toString().trim());
                    if (!TextUtils.isEmpty(s.toString().trim())) {
                        if (s.toString().matches(regex)) {
                            addedAmount = tempAmount;

                            proceedToAddBtn.setEnabled(true);
                            proceedToAddBtn.setTextColor(Color.parseColor("#ffffff"));
                            errorTv.setVisibility(View.GONE);

                        } else {
                            proceedToAddBtn.setEnabled(false);
                            proceedToAddBtn.setTextColor(Color.parseColor("#70ffffff"));
                            errorTv.setVisibility(View.VISIBLE);
                            errorTv.setText("Please Enter Valid Amount");


                        }

                    } else {

                        proceedToAddBtn.setEnabled(false);
                        proceedToAddBtn.setTextColor(Color.parseColor("#70ffffff"));
                        errorTv.setVisibility(View.VISIBLE);
                        errorTv.setText("Please Enter Valid Amount");
                    }

                } catch (NumberFormatException e) {
                    proceedToAddBtn.setEnabled(false);
                    proceedToAddBtn.setTextColor(Color.parseColor("#70ffffff"));
                    errorTv.setVisibility(View.VISIBLE);
                    errorTv.setText("Please Enter Valid Amount");
                    Toast.makeText(getActivity(), "" + e, Toast.LENGTH_SHORT).show();

                }

            }
        });

        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewWalletDetails();
            }
        });

        proceedToAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String mid = "XqFDwI90885159612284";
                final String customerId = new MyPrefernces(Objects.requireNonNull(getActivity())).readUserId();
                final String orderId = generateString().toString().substring(0, 28);
                final String callBackUrl = "https://pguat.paytm.com/paytmchecksum/paytmCallback.jsp";

                if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, 101);
                }


                if (checkAmountValidity(Double.parseDouble(addMoneyEt.getText().toString().trim()))) {
                    //Toast.makeText(context, "" + addMoneyEt.getText().toString().trim(), Toast.LENGTH_SHORT).show();
                    getChecksum(mid, customerId, orderId, callBackUrl);
                    errorTv.setVisibility(View.GONE);
                } else {
                    errorTv.setVisibility(View.VISIBLE);
                    errorTv.setText("You have exceed the transaction limit fo this month");
                }


            }
        });


        sheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View view, int i) {
               /* switch (i) {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED: {

                    }
                    break;
                    case BottomSheetBehavior.STATE_COLLAPSED: {

                    }
                    break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        break;
                }*/
            }

            @Override
            public void onSlide(@NonNull View view, float v) {

            }
        });
    }

    private void toggleBottomSheet() {
        if (sheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
            sheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);

        } else {
            sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

        }
    }


    private void getChecksum(final String mid, final String customerId, final String orderId, final String callBackUrl) {

        walletProgressBar.setVisibility(View.VISIBLE);
        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<PaytmChecksum> query = apiInterface.getChecksum(mid, orderId, customerId,
                "WAP", addedAmount + "", "WEBSTAGING", "Retail", callBackUrl);


        query.enqueue(new Callback<PaytmChecksum>() {
            @Override
            public void onResponse(Call<PaytmChecksum> call, Response<PaytmChecksum> response) {

                walletProgressBar.setVisibility(View.GONE);
                if (response.isSuccessful()) {

                    assert response.body() != null;
                    String checkSumHash = response.body().getChecksumhash();


                    PaytmPGService paytmPGService = PaytmPGService.getStagingService("");

                    HashMap<String, String> hashMap = new HashMap<>();

                    hashMap.put("MID", "XqFDwI90885159612284");
                    hashMap.put("ORDER_ID", orderId);
                    hashMap.put("CUST_ID", customerId);
                    hashMap.put("CHANNEL_ID", "WAP");
                    hashMap.put("TXN_AMOUNT", addedAmount + "");
                    hashMap.put("WEBSITE", "WEBSTAGING");
                    hashMap.put("INDUSTRY_TYPE_ID", "Retail");
                    hashMap.put("CALLBACK_URL", callBackUrl);
                    hashMap.put("CHECKSUMHASH", checkSumHash);


                    PaytmOrder paytmOrder = new PaytmOrder(hashMap);
                    paytmPGService.initialize(paytmOrder, null);

                    paytmPGService.startPaymentTransaction(getActivity(), true, true, new PaytmPaymentTransactionCallback() {
                        @Override
                        public void onTransactionResponse(Bundle inResponse) {

                            Toast.makeText(getActivity(), "Payment Transaction Response" + inResponse.toString(), Toast.LENGTH_SHORT).show();
                            if (Objects.equals(inResponse.getString("STATUS"), "TXN_SUCCESS")) {
                                addMoneyEt.setText("");
                                addMoneyEt.setFocusable(false);
                                creditMoneyToWallet(inResponse.getString("TXNAMOUNT"), orderId, inResponse.getString("TXNID"));
                                sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

                            }


                        }

                        @Override
                        public void networkNotAvailable() {
                            Toast.makeText(getActivity(), "Network connection error: Check your internet connectivity", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void clientAuthenticationFailed(String inErrorMessage) {
                            Toast.makeText(getActivity(), "Authentication failed: Server error" + inErrorMessage, Toast.LENGTH_LONG).show();

                        }

                        @Override
                        public void someUIErrorOccurred(String inErrorMessage) {
                            Toast.makeText(getActivity(), "UI Error " + inErrorMessage, Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {
                            Toast.makeText(getActivity(), "Unable to load webpage " + inErrorMessage, Toast.LENGTH_LONG).show();


                        }

                        @Override
                        public void onBackPressedCancelTransaction() {
                            Toast.makeText(getActivity(), "Transaction cancelled", Toast.LENGTH_LONG).show();
                        }


                        @Override
                        public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {
                            Toast.makeText(getActivity(), "Transaction cancelled", Toast.LENGTH_LONG).show();
                        }
                    });


                }
            }

            @Override
            public void onFailure(Call<PaytmChecksum> call, Throwable t) {
                walletProgressBar.setVisibility(View.GONE);
                Toast.makeText(getContext(), "" + t.getCause(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void creditMoneyToWallet(String txnAmount, String orderId, String txnId) {
        walletProgressBar.setVisibility(View.VISIBLE);
        Toast.makeText(context, "" + txnAmount, Toast.LENGTH_SHORT).show();
        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<ResponseBody> query = apiInterface.addMoneyToWallet(userName, txnAmount, orderId, txnId);
        query.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                walletProgressBar.setVisibility(View.GONE);

                if (response.isSuccessful()) {
                    viewWalletDetails();
                    //Toast.makeText(getActivity(), "Amount Added Successfully", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                walletProgressBar.setVisibility(View.GONE);
            }
        });


    }


    private String generateString() {
        String uuid = UUID.randomUUID().toString();
        return uuid.replaceAll("-", "");
    }


    private void viewWalletDetails() {
        walletProgressBar.setVisibility(View.VISIBLE);
        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<KplarWallet> query = apiInterface.viewWalletMoney(userName);
        query.enqueue(new Callback<KplarWallet>() {
            @Override
            public void onResponse(Call<KplarWallet> call, Response<KplarWallet> response) {
                walletProgressBar.setVisibility(View.GONE);

                if (response.isSuccessful()) {


                    assert response.body() != null;
                    if (response.body().getResponse().equals("true")) {
                        walletBal = Double.parseDouble(response.body().getData().getTotalwalletbalance());
                        balanceTv.setText(String.format("%s", walletBal));

                        currentMonthTxnAmount = response.body().getData().getCurrentmonthtransactionamount();

                        tansactionhistoryList = response.body().getData().getTansactionhistory();

                        if (tansactionhistoryList != null) {
                            txnHistoryContainer.setVisibility(View.VISIBLE);
                            transactionHistoryAdapter = new TransactionHistoryAdapter(tansactionhistoryList, context);
                            txnHistoryRv.setAdapter(transactionHistoryAdapter);
                            transactionHistoryAdapter.notifyDataSetChanged();
                        } else txnHistoryContainer.setVisibility(View.GONE);

                    }
                }

            }

            @Override
            public void onFailure(Call<KplarWallet> call, Throwable t) {
                txnHistoryContainer.setVisibility(View.GONE);
                walletProgressBar.setVisibility(View.GONE);
            }
        });

    }

    private boolean checkAmountValidity(double enteredAmount) {
        if (((enteredAmount + walletBal > 10000.00) && (enteredAmount + currentMonthTxnAmount > 10000.00))) {
            Toast.makeText(context, "" + ((enteredAmount + walletBal > 10000.00) && (currentMonthTxnAmount > 10000.00)), Toast.LENGTH_SHORT).show();
            return false;

        } else return true;


    }
}
