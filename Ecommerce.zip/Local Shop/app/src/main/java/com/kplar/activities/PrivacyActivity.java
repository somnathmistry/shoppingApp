package com.kplar.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

import com.kplar.R;

public class PrivacyActivity extends AppCompatActivity {
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);
        toolbar = findViewById(R.id.privacy_toolbar);
        toolbar.setTitle("Privacy & Policy");
        setSupportActionBar(toolbar);
        toolbar.setTitle("Privacy & Policy");
        toolbar.setTitleTextColor(getResources().getColor(R.color.white_color));
        toolbar.setTitleTextAppearance(this, R.style.myFont);
    }
}