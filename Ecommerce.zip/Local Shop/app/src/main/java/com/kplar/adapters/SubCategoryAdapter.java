package com.kplar.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kplar.R;
import com.kplar.activities.ProductsActivity;
import com.kplar.models.subcategoriesPackage.SubCategoryData;

import java.util.List;

public class SubCategoryAdapter extends RecyclerView.Adapter<SubCategoryAdapter.MyViewHolder> {

    private List<SubCategoryData> subCategoryDataList;
    private Context context;
    private OnSubCategoryListener onSubCategoryListener;

    public SubCategoryAdapter(List<SubCategoryData> subCategoryDataList, Context context) {
        this.subCategoryDataList = subCategoryDataList;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_subcategory_layout, parent, false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(subCategoryDataList.get(position).getName());
        Glide.with(context).load(subCategoryDataList.get(position).getImage()).into(holder.image);


    }

    @Override
    public int getItemCount() {
        return subCategoryDataList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView image;
        TextView name;
        CardView subCategoryCardView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.subCatImgId);
            name = itemView.findViewById(R.id.subcatnameId);
            subCategoryCardView = itemView.findViewById(R.id.sub_category_cv);

            itemView.setOnClickListener(this);


        }

        @Override
        public void onClick(View v) {



                if (subCategoryDataList.get(getAdapterPosition()).getContent().equals("s")) {
                    onSubCategoryListener = (OnSubCategoryListener) context;
                    onSubCategoryListener.fetchSubcategoryDetails(subCategoryDataList.get(getAdapterPosition()).getName(),
                            subCategoryDataList.get(getAdapterPosition()).getId());
                    Toast.makeText(context, ""+subCategoryDataList.get(getAdapterPosition()).getId(), Toast.LENGTH_SHORT).show();


                } else if (subCategoryDataList.get(getAdapterPosition()).getContent().equals("p")) {
                    Intent intent = new Intent(context, ProductsActivity.class);
                    intent.putExtra("categoryName", subCategoryDataList.get(getAdapterPosition()).getName());
                    intent.putExtra("id", subCategoryDataList.get(getAdapterPosition()).getId());
                    context.startActivity(intent);

                }




        }


    }

    public interface OnSubCategoryListener {

        void fetchSubcategoryDetails(String subcategoryName, String subcategoryId);

    }
}
