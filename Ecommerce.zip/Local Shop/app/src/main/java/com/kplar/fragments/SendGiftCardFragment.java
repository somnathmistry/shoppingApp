package com.kplar.fragments;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.kplar.R;
import com.kplar.models.paytmPackage.PaytmChecksum;
import com.kplar.models.sendGiftCardPackage.SendGiftCard;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import java.util.HashMap;
import java.util.Objects;
import java.util.UUID;

import iammert.com.library.StatusView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SendGiftCardFragment extends Fragment {
    EditText recipientEmailIdEt, confirmRecipientEmailEt, messageEt, giftCardAmountEt;
    Button proceedToPayBtn;
    Context context;
    String email, orderId, message, userName, giftCardAmount, txnId, name;
    boolean isEmailValidated = false, isConfirmEmailValidated = false, isGiftCardAmountValidated = false;
    ApiInterface apiInterface;
    StatusView statusView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_send_gift_card, container, false);

        recipientEmailIdEt = view.findViewById(R.id.recep_email_et);
        confirmRecipientEmailEt = view.findViewById(R.id.confirm_recep_email_et);
        messageEt = view.findViewById(R.id.message_et);
        giftCardAmountEt = view.findViewById(R.id.gift_card_amount_et);
        statusView = view.findViewById(R.id.status);

        proceedToPayBtn = view.findViewById(R.id.proceed_pay_btn);
        userName = new MyPrefernces(context).readUserName();


        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onStart() {
        super.onStart();
        Bundle bundle = getArguments();
        if (bundle != null) {

            String giftAmount = getArguments().getString("amount", "");
            if (!giftAmount.isEmpty()) {
                giftCardAmountEt.setText(giftAmount);
                isGiftCardAmountValidated = true;
                isEachOneValidated();
            } else {

                isGiftCardAmountValidated = false;
                isEachOneValidated();
            }

        }


    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        recipientEmailIdEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                //email regular exp
                String regex = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";
                if (!TextUtils.isEmpty(s.toString().trim())) {
                    if (!(s.toString().matches(regex))) {
                        recipientEmailIdEt.setError("InValid EmailId");
                        isEmailValidated = false;
                        proceedToPayBtn.setEnabled(false);
                        proceedToPayBtn.setAlpha((float) 0.7);
                    } else {
                        proceedToPayBtn.setEnabled(true);
                        proceedToPayBtn.setAlpha((float) 1);
                        isEmailValidated = true;
                        isEachOneValidated();

                    }

                } else {
                    isEmailValidated = false;
                    proceedToPayBtn.setEnabled(false);
                    proceedToPayBtn.setAlpha((float) 0.7);
                }


            }
        });

        confirmRecipientEmailEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                try {
                    String recipientEmailId = recipientEmailIdEt.getText().toString();
                    String confirmRecipientEmail = s.toString();
                    if (confirmRecipientEmail.length() > 0 && recipientEmailId.length() > 0) {
                        if (confirmRecipientEmail.equals(recipientEmailId)) {
                            email = recipientEmailIdEt.getText().toString();
                            proceedToPayBtn.setEnabled(true);
                            proceedToPayBtn.setAlpha((float) 1);
                            isConfirmEmailValidated = true;
                            isEachOneValidated();
                        } else {
                            confirmRecipientEmailEt.setError("Email not Matched");
                            isConfirmEmailValidated = false;

                            proceedToPayBtn.setEnabled(false);
                            proceedToPayBtn.setAlpha((float) 0.7);
                        }

                    } else {
                        isConfirmEmailValidated = false;
                        //confirmRecipientEmailEt.setError("Email not MatchedTwo");
                        proceedToPayBtn.setEnabled(false);
                        proceedToPayBtn.setAlpha((float) 0.7);
                    }
                } catch (Exception e) {
                    confirmRecipientEmailEt.setError("Email not Matched");
                    proceedToPayBtn.setEnabled(false);
                    proceedToPayBtn.setAlpha((float) 0.7);
                }

            }
        });

        messageEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                proceedToPayBtn.setEnabled(true);
                proceedToPayBtn.setAlpha((float) 1);
                message = messageEt.getText().toString();


            }
        });

        giftCardAmountEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                try {

                    String regex = "^[1-9][0-9]*(\\.[0-9]{1,2})?$";
                    if (!TextUtils.isEmpty(s.toString().trim())) {
                        if (s.toString().matches(regex)) {
                            int amount = Integer.parseInt(giftCardAmountEt.getText().toString().trim());
                            if (amount >= 100 && amount <= 5000) {
                                giftCardAmount = giftCardAmountEt.getText().toString().trim();
                                proceedToPayBtn.setEnabled(true);
                                proceedToPayBtn.setAlpha((float) 1);
                                isGiftCardAmountValidated = true;
                                isEachOneValidated();

                            } else {
                                isGiftCardAmountValidated = false;
                                giftCardAmountEt.setError("Amount Must Be In Between 100 to 5000");
                                proceedToPayBtn.setEnabled(false);
                                proceedToPayBtn.setAlpha((float) 0.7);
                            }
                        } else {
                            isGiftCardAmountValidated = false;
                            giftCardAmountEt.setError("Amount Must Be In Between 100 to 5000");
                            proceedToPayBtn.setEnabled(false);
                            proceedToPayBtn.setAlpha((float) 0.7);
                        }

                    } else {
                        giftCardAmountEt.setError("Amount Must Be In Between 100 to 5000");
                        isGiftCardAmountValidated = false;
                        proceedToPayBtn.setEnabled(false);
                        proceedToPayBtn.setAlpha((float) 0.7);

                    }
                    // Toast.makeText(context, "" + s.toString(), Toast.LENGTH_SHORT).show();
                } catch (Exception e) {

                    giftCardAmountEt.setError("Amount Must Be In Between 100 to 5000");
                    proceedToPayBtn.setEnabled(false);
                    proceedToPayBtn.setAlpha((float) 0.7);
                }
            }
        });


        proceedToPayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "TRUE", Toast.LENGTH_SHORT).show();

                final String mid = "XqFDwI90885159612284";
                final String customerId = new MyPrefernces(Objects.requireNonNull(getActivity())).readUserId();
                final String orderId = generateString().toString().substring(0, 28);
                final String callBackUrl = "https://pguat.paytm.com/paytmchecksum/paytmCallback.jsp";

                if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, 101);
                }


                getChecksum(mid, customerId, orderId, callBackUrl);


            }
        });
    }


    public void getChecksum(final String mid, final String customerId, final String orderId, final String callBackUrl) {


        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<PaytmChecksum> query = apiInterface.getChecksum(mid, orderId, customerId,
                "WAP", giftCardAmountEt.getText().toString(), "WEBSTAGING", "Retail", callBackUrl);

        query.enqueue(new Callback<PaytmChecksum>() {
            @Override
            public void onResponse(Call<PaytmChecksum> call, Response<PaytmChecksum> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String checkSumHash = response.body().getChecksumhash();


                    PaytmPGService paytmPGService = PaytmPGService.getStagingService("");

                    HashMap<String, String> hashMap = new HashMap<>();

                    hashMap.put("MID", "XqFDwI90885159612284");
                    hashMap.put("ORDER_ID", orderId);
                    hashMap.put("CUST_ID", customerId);
                    hashMap.put("CHANNEL_ID", "WAP");
                    hashMap.put("TXN_AMOUNT", giftCardAmountEt.getText().toString());
                    hashMap.put("WEBSITE", "WEBSTAGING");
                    hashMap.put("INDUSTRY_TYPE_ID", "Retail");
                    hashMap.put("CALLBACK_URL", callBackUrl);
                    hashMap.put("CHECKSUMHASH", checkSumHash);

                    PaytmOrder paytmOrder = new PaytmOrder(hashMap);
                    paytmPGService.initialize(paytmOrder, null);


                    paytmPGService.startPaymentTransaction(getActivity(), true, true, new PaytmPaymentTransactionCallback() {
                        @Override
                        public void onTransactionResponse(Bundle inResponse) {

                            Toast.makeText(getActivity(), "Payment Transaction Response" + inResponse.toString(), Toast.LENGTH_SHORT).show();
                            if (Objects.equals(inResponse.getString("STATUS"), "TXN_SUCCESS")) {


                                uploadSendGiftCardPayLoad(inResponse.getString("TXNAMOUNT"), orderId, inResponse.getString("TXNID"));
                                statusView.getCompleteView();

                            }


                        }

                        @Override
                        public void networkNotAvailable() {
                            Toast.makeText(getActivity(), "Network connection error: Check your internet connectivity", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void clientAuthenticationFailed(String inErrorMessage) {
                            Toast.makeText(getActivity(), "Authentication failed: Server error" + inErrorMessage, Toast.LENGTH_LONG).show();

                        }

                        @Override
                        public void someUIErrorOccurred(String inErrorMessage) {
                            Toast.makeText(getActivity(), "UI Error " + inErrorMessage, Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {
                            Toast.makeText(getActivity(), "Unable to load webpage " + inErrorMessage, Toast.LENGTH_LONG).show();


                        }

                        @Override
                        public void onBackPressedCancelTransaction() {
                            Toast.makeText(getActivity(), "Transaction cancelled", Toast.LENGTH_LONG).show();
                        }


                        @Override
                        public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {
                            Toast.makeText(getActivity(), "Transaction cancelled", Toast.LENGTH_LONG).show();
                        }
                    });

                }

            }

            @Override
            public void onFailure(Call<PaytmChecksum> call, Throwable t) {

            }
        });
    }

    private void uploadSendGiftCardPayLoad(String txnAmount, String orderId, String txnId) {

        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<SendGiftCard> query = apiInterface.uploadSendGiftCardPayLoad(userName,
                orderId,
                txnAmount,
                txnId,
                "Gift Card",
                recipientEmailIdEt.getText().toString());

        query.enqueue(new Callback<SendGiftCard>() {
            @Override
            public void onResponse(Call<SendGiftCard> call, Response<SendGiftCard> response) {
                if (response.isSuccessful()) {

                    assert response.body() != null;
                    if (response.body().getResponse().equals("ok"))
                        Toast.makeText(context, "Gift Card Sent Successfully", Toast.LENGTH_SHORT).show();
                    else Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<SendGiftCard> call, Throwable t) {

                Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public boolean isEachOneValidated() {
        if (isConfirmEmailValidated && isEmailValidated && isGiftCardAmountValidated) {
            proceedToPayBtn.setEnabled(true);
            proceedToPayBtn.setAlpha((float) 1);
            return true;

        }
        proceedToPayBtn.setEnabled(false);
        proceedToPayBtn.setAlpha((float) 0.7);
        return false;


    }

    private String generateString() {
        String uuid = UUID.randomUUID().toString();
        return uuid.replaceAll("-", "");
    }


}
