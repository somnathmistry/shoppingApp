package com.kplar.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.kplar.R;
import com.kplar.activities.KplarWalletActivity;

public class GiftCardFragment extends Fragment {


    OnFragmentChangeListener onFragmentChangeListener;
    private Context mContext;
    private Button sendGiftCardBtn, receiveGiftCardBtn, checkWalletBalanceBtn;
    ImageButton addMoneyToGiftCardBtn;
    ConstraintLayout gift100Btn, gift500Btn, gift1000Btn, gift2000Btn, gift3000Btn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_gift_card, container, false);

        sendGiftCardBtn = view.findViewById(R.id.send_gift_card_btn);
        receiveGiftCardBtn = view.findViewById(R.id.receive_gift_card_btn);
        checkWalletBalanceBtn = view.findViewById(R.id.wallet_balance_btn);
        addMoneyToGiftCardBtn = view.findViewById(R.id.add_money_to_gift_card_btn);

        gift100Btn = view.findViewById(R.id.gift_card_100_btn);
        gift500Btn = view.findViewById(R.id.gift_card_500_btn);
        gift1000Btn = view.findViewById(R.id.gift_card_1000_btn);
        gift2000Btn = view.findViewById(R.id.gift_card_2000_btn);
        gift3000Btn = view.findViewById(R.id.gift_card_3000_btn);


        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context;

        onFragmentChangeListener = (OnFragmentChangeListener) getActivity();


    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        gift100Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentChangeListener.onAmountSendListener("100");

            }
        });
        gift500Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentChangeListener.onAmountSendListener("500");

            }
        });
        gift1000Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentChangeListener.onAmountSendListener("1000");

            }
        });
        gift2000Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentChangeListener.onAmountSendListener("2000");
            }
        });
        gift3000Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentChangeListener.onAmountSendListener("3000");

            }
        });


        addMoneyToGiftCardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentChangeListener.onAmountSendListener("");
            }
        });

        sendGiftCardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentChangeListener.setOnFragment("send Gift Card Fragment");

            }
        });

        receiveGiftCardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentChangeListener.setOnFragment("receive Gift Card Fragment");
            }
        });

        checkWalletBalanceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, KplarWalletActivity.class);
                mContext.startActivity(intent);

            }
        });
    }


    public interface OnFragmentChangeListener {

        void setOnFragment(String fgrName);

        void onAmountSendListener(String giftAmount);
    }
}
