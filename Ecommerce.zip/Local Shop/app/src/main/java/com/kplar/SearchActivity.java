package com.kplar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kplar.activities.ProductsActivity;
import com.kplar.adapters.ProductsAdapter;
import com.kplar.adapters.SearchProductAdapter;
import com.kplar.models.SearchProduct;
import com.kplar.models.SearchProductData;
import com.kplar.models.productsPackage.Products;
import com.kplar.models.productsPackage.ProductsData;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchActivity extends AppCompatActivity {
    private GridLayoutManager gridLayoutManager;
    private RecyclerView recyclerView;
    SearchProductAdapter searchProductAdapter;
    ApiInterface apiInterface;
    List<SearchProductData> searchProductData;
    EditText searchEdit;
    String s;

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView = findViewById(R.id.recycleSearchId);
        recyclerView.setLayoutManager(gridLayoutManager);
        button = findViewById(R.id.serachButton);

        searchEdit = findViewById(R.id.searchId);
        //searchString = searchEdit.getText().toString();

        getSearchProduct("");

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                getSearchProduct(searchEdit.getText().toString());

            }
        });

    }

    private void getSearchProduct(String search) {

        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<SearchProduct> query = apiInterface.getSearchProducts(search);
        query.enqueue(new Callback<SearchProduct>() {
            @Override
            public void onResponse(Call<SearchProduct> call, Response<SearchProduct> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(SearchActivity.this, "" + response.code(), Toast.LENGTH_SHORT).show();
                    assert response.body() != null;
                    searchProductData = response.body().getData();
                    searchProductAdapter = new SearchProductAdapter(searchProductData, SearchActivity.this);
                    recyclerView.setAdapter(searchProductAdapter);
                    searchProductAdapter.notifyDataSetChanged();
                    //Toast.makeText(SearchActivity.this, "Value "+search , Toast.LENGTH_SHORT).show();

                }

            }

            @Override
            public void onFailure(Call<SearchProduct> call, Throwable t) {
                String s = t.getMessage();
                Toast.makeText(SearchActivity.this, "Error " + s, Toast.LENGTH_SHORT).show();

            }
        });

    }

}