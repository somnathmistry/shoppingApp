package com.kplar.fragments;


import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.kplar.R;
import com.kplar.activities.SignUpActivity;
import com.kplar.models.AddAddress;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;
import static com.basgeekball.awesomevalidation.ValidationStyle.BASIC;

/**
 * A simple {@link Fragment} subclass.
 */
public class ShippingAddressFormFragment extends Fragment {
    Button addAdressBn;
    EditText respName, mobileNo, stName, districName, pinCode, stateName, landMark;
    private RadioButton homeBn, officeBn;
    private RadioGroup radioGroup;
    private ApiInterface apiInterface;
    String selectedRadioButton, respNameStr, mobileStr, stNameStr, districStr, pinCodeStr, stateStr, landStr, fullAddress;
    String user;
    private AwesomeValidation awesomeValidation;
    private ProgressDialog progressDialog;


    MyPrefernces myPrefernces;
    //Context context;


    public ShippingAddressFormFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_shipping_address_form, container, false);
        addAdressBn = view.findViewById(R.id.button3);
        homeBn = view.findViewById(R.id.homeRb);
        officeBn = view.findViewById(R.id.officeBn);

        respName = view.findViewById(R.id.editText);
        mobileNo = view.findViewById(R.id.editText2);
        stName = view.findViewById(R.id.editText4);
        districName = view.findViewById(R.id.editText5);
        pinCode = view.findViewById(R.id.editText6);
        stateName = view.findViewById(R.id.editText7);
        landMark = view.findViewById(R.id.editText8);
        radioGroup = view.findViewById(R.id.radioGroup2);

        myPrefernces = new MyPrefernces(getActivity());
        user = myPrefernces.readUserName();
        awesomeValidation = new AwesomeValidation(BASIC);

        addAdressBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                respNameStr = respName.getText().toString().trim();
                mobileStr = mobileNo.getText().toString().trim();
                stNameStr = stName.getText().toString().trim();
                districStr = districName.getText().toString();
                pinCodeStr = pinCode.getText().toString().trim();
                stateStr = stateName.getText().toString().trim();
                landStr = landMark.getText().toString().trim();

                progressDialog = new ProgressDialog(getActivity());

                if (homeBn.isChecked()) {
                    selectedRadioButton = homeBn.getText().toString();
                } else if (officeBn.isChecked()) {
                    selectedRadioButton = officeBn.getText().toString();
                }

                if (TextUtils.isEmpty(respNameStr)) {
                    Toast.makeText(getActivity(), "Please Enter Recipient Name", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(mobileStr)) {
                    Toast.makeText(getActivity(), "Please Mobile No.", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(stNameStr)) {
                    Toast.makeText(getActivity(), "Please Enter Street Name", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(districStr)) {
                    Toast.makeText(getActivity(), "Please Enter District Name", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(pinCodeStr)) {
                    Toast.makeText(getActivity(), "Please Enter Pin Name", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(stateStr)) {
                    Toast.makeText(getActivity(), "Please Enter State Name", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(landStr)) {
                    Toast.makeText(getActivity(), "Please Enter a Landmark", Toast.LENGTH_SHORT).show();
                }else {

                    progressDialog.setTitle("Adding address");
                    progressDialog.setMessage("Please wait, your "+selectedRadioButton+" address is adding");
                    progressDialog.setCanceledOnTouchOutside(false);
                    progressDialog.show();

                    addAddress();

//                    Toast.makeText(getActivity(), "Radio Bn " + selectedRadioButton, Toast.LENGTH_SHORT).show();
//                    Toast.makeText(getActivity(), "User name " + user, Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "onClick: " + user + ", " + respName.getText().toString() + ", "
                            + mobileNo.getText().toString() + ", "
                            + selectedRadioButton + ", "
                            + stName.getText().toString() + ", "
                            + districName.getText().toString() + ", "
                            + pinCode.getText().toString() + ", "
                            + stateName.getText().toString() + ", "
                            + landMark.getText().toString());
                    //Toast.makeText(context, "User "+myPrefernces.readUserName(), Toast.LENGTH_SHORT).show();

                }
            }
        });
        return view;
    }


    private void addAddress() {

        fullAddress = selectedRadioButton + ",\n" + respNameStr + ",\n" + mobileStr + ",\n" + stNameStr + ",\n" + districStr + ",\n" + pinCodeStr + ",\n" + stateStr + ",\n" + landStr;
        Toast.makeText(getActivity(), "Full " + fullAddress, Toast.LENGTH_SHORT).show();
        Log.i(TAG, "addAddress: " + fullAddress);

        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<AddAddress> addressCall = apiInterface.addAddress(user, fullAddress);

        addressCall.enqueue(new Callback<AddAddress>() {
            @Override
            public void onResponse(Call<AddAddress> call, Response<AddAddress> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getActivity(), "Address added successfully", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<AddAddress> call, Throwable t) {

                Toast.makeText(getActivity(), "Please check your network", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
