package com.kplar.fragments;


import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.kplar.R;
import com.kplar.activities.PaymentByCodActivity;
import com.kplar.activities.PaymentByKplarWalletActivity;
import com.kplar.activities.RozerPayActivity;
import com.kplar.activities.ShippingAddressFormActivity;
import com.kplar.adapters.ProductForBillAdapter;
import com.kplar.models.billAndProductPackage.BillProduct;
import com.kplar.models.billAndProductPackage.Data;
import com.kplar.models.cartPackage.Cart;
import com.kplar.models.parcel.ParcelableProduct;
import com.kplar.models.paytmPackage.PaytmChecksum;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class BillDetailsFragment extends Fragment {
    Bundle bundle;

    CouponVerifierDialogFragment couponVerifierDialogFragment;
    ArrayList<String> items;
    private CardView paymentByBs, oneProduct;
    private BottomSheetBehavior sheetBehavior;
    int flag;
    private TextView totalAmountTv, productName, sellingPrice, disc;
    private RecyclerView productsForBillRecyclerView;
    private ApiInterface apiInterface;
    private MyPrefernces myPrefernces;
    private Context context;
    private String userName, paymentType;
    private double totalAmount;
    private ImageButton addShippingAddressBtn;
    private List<Data> billList;
    private List<com.kplar.models.cartPackage.Data> cartItems;
    private ProductForBillAdapter productForBillAdapter;
    private Button paymentBtn, closeBtn, proceedBtn, goForCouponBtn;
    private RadioGroup radioGroup;
    private RadioButton kplarWalletRb, codRb, othersRb;
    TableLayout tableLayout;
    ImageView productImg;
    private ConstraintLayout couponContainer;
    ParcelableProduct parcelableProduct;
    String string;


    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_bill_details, container, false);
        //Toast.makeText(context, "Value "+parcelableProduct.getSellingPrice(), Toast.LENGTH_SHORT).show();

        tableLayout = view.findViewById(R.id.main_table);

        totalAmountTv = view.findViewById(R.id.total_amount_tv);
        addShippingAddressBtn = view.findViewById(R.id.add_shipping_address_ib);
        paymentByBs = view.findViewById(R.id.payment_by_bs);
        paymentBtn = view.findViewById(R.id.go_for_pay_btn);
        couponContainer = view.findViewById(R.id.coupon_container);

        productImg = view.findViewById(R.id.product_image);
        productName = view.findViewById(R.id.product_name_ind);
        sellingPrice = view.findViewById(R.id.selling_price);
        disc = view.findViewById(R.id.discount_ind);

        oneProduct = view.findViewById(R.id.one_product);

        goForCouponBtn = view.findViewById(R.id.go_for_coupon_btn);

        closeBtn = view.findViewById(R.id.close_btn);
        proceedBtn = view.findViewById(R.id.proceed_btn);

        radioGroup = view.findViewById(R.id.payments_option_rg);
        kplarWalletRb = view.findViewById(R.id.kplar_wallet_rb);
        codRb = view.findViewById(R.id.cod_rb);
        othersRb = view.findViewById(R.id.others_rb);


        productsForBillRecyclerView = view.findViewById(R.id.product_for_bill_recycler_view);
        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(context);
        linearLayoutManager1.setOrientation(LinearLayoutManager.HORIZONTAL);
        productsForBillRecyclerView.setLayoutManager(linearLayoutManager1);
        productsForBillRecyclerView.setHasFixedSize(true);

        myPrefernces = new MyPrefernces(context);
        userName = myPrefernces.readUserName();


        goForCouponBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                couponVerifierDialogFragment = new CouponVerifierDialogFragment();
                couponVerifierDialogFragment.show(Objects.requireNonNull(getActivity()).getSupportFragmentManager(), "Review Dialog");
            }
        });

        sheetBehavior = BottomSheetBehavior.from(paymentByBs);
        sheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View view, int i) {
               /* switch (i) {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED: {

                    }
                    break;
                    case BottomSheetBehavior.STATE_COLLAPSED: {

                    }
                    break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        break;
                }*/
            }

            @Override
            public void onSlide(@NonNull View view, float v) {

            }
        });

        kplarWalletRb.setChecked(true);
        paymentType = "wallet";


        paymentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleBottomSheet();
            }
        });

        addShippingAddressBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, ShippingAddressFormActivity.class);
                context.startActivity(intent);


            }
        });
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleBottomSheet();
            }
        });


        proceedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                switch (paymentType) {
                    case "others":

                        ParcelableProduct p = new ParcelableProduct();
                        Toast.makeText(context, "others button Clicked", Toast.LENGTH_SHORT).show();
                        p.setSellingPrice(totalAmount);

                        Intent i = new Intent(getActivity(), RozerPayActivity.class);
                        i.putExtra("amount",p);
                        startActivity(i);


/*
                        final String mid = "XqFDwI90885159612284";
                        final String customerId = new MyPrefernces(context).readUserId();
                        final String orderId = generateString().substring(0, 28);
                        final String callBackUrl = "https://pguat.paytm.com/paytmchecksum/paytmCallback.jsp";

                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(Objects.requireNonNull(getActivity()), new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, 101);
                        }


                        getChecksum(mid, customerId, orderId, callBackUrl);
*/
                        break;
                    case "cod":
                        Intent intent1 = new Intent(context, PaymentByCodActivity.class);
                        context.startActivity(intent1);
                        break;
                    case "wallet":

                        Intent intent = new Intent(context, PaymentByKplarWalletActivity.class);
                        context.startActivity(intent);


                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + paymentType);
                }
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {


                if (checkedId == R.id.kplar_wallet_rb) {
                    paymentType = "wallet";


                } else if (checkedId == R.id.cod_rb) {
                    kplarWalletRb.setChecked(false);
                    paymentType = "cod";


                } else if (checkedId == R.id.others_rb) {
                    kplarWalletRb.setChecked(false);
                    paymentType = "others";

                }
            }
        });


        return view;
    }


    private void toggleBottomSheet() {
        if (sheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
            sheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);

        } else {
            sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

        }
    }

    private void getChecksum(final String mid, final String customerId, final String orderId, final String callBackUrl) {


        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<PaytmChecksum> query = apiInterface.getChecksum(mid, orderId, customerId,
                "WAP", totalAmount + "", "WEBSTAGING", "Retail", callBackUrl);

        query.enqueue(new Callback<PaytmChecksum>() {
            @Override
            public void onResponse(Call<PaytmChecksum> call, Response<PaytmChecksum> response) {


                if (response.isSuccessful()) {

                    String checkSumHash = Objects.requireNonNull(response.body()).getChecksumhash();


                    PaytmPGService paytmPGService = PaytmPGService.getStagingService("");

                    HashMap<String, String> hashMap = new HashMap<>();

                    hashMap.put("MID", "XqFDwI90885159612284");
                    hashMap.put("ORDER_ID", orderId);
                    hashMap.put("CUST_ID", customerId);
                    hashMap.put("CHANNEL_ID", "WAP");
                    hashMap.put("TXN_AMOUNT", totalAmount + "");
                    hashMap.put("WEBSITE", "WEBSTAGING");
                    hashMap.put("INDUSTRY_TYPE_ID", "Retail");
                    hashMap.put("CALLBACK_URL", callBackUrl);
                    hashMap.put("CHECKSUMHASH", checkSumHash);


                    PaytmOrder paytmOrder = new PaytmOrder(hashMap);
                    paytmPGService.initialize(paytmOrder, null);

                    paytmPGService.startPaymentTransaction(context, true, true, new PaytmPaymentTransactionCallback() {
                        @Override
                        public void onTransactionResponse(Bundle inResponse) {

                            Toast.makeText(context, "Payment Transaction Response" + inResponse.toString(), Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void networkNotAvailable() {
                            Toast.makeText(context, "Network connection error: Check your internet connectivity", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void clientAuthenticationFailed(String inErrorMessage) {
                            Toast.makeText(context, "Authentication failed: Server error" + inErrorMessage, Toast.LENGTH_LONG).show();

                        }

                        @Override
                        public void someUIErrorOccurred(String inErrorMessage) {
                            Toast.makeText(context, "UI Error " + inErrorMessage, Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {
                            Toast.makeText(context, "Unable to load webpage " + inErrorMessage, Toast.LENGTH_LONG).show();


                        }

                        @Override
                        public void onBackPressedCancelTransaction() {
                            Toast.makeText(context, "Transaction cancelled", Toast.LENGTH_LONG).show();
                        }


                        @Override
                        public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {
                            Toast.makeText(context, "Transaction cancelled", Toast.LENGTH_LONG).show();
                        }
                    });


                }
            }

            @Override
            public void onFailure(Call<PaytmChecksum> call, Throwable t) {

                Toast.makeText(context, "" + t.getCause(), Toast.LENGTH_SHORT).show();

            }
        });
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        Bundle bundle = getArguments();
        assert bundle != null;
        String src = bundle.getString("src");
        parcelableProduct = bundle.getParcelable("product");
        assert src != null;


        if (src.equals("cart")) {

            flag = 0;
            getAllCartItems(userName);
            getProductWithBill(userName);
            productsForBillRecyclerView.setVisibility(View.VISIBLE);
            oneProduct.setVisibility(View.GONE);
            // Toast.makeText(context, "" + src, Toast.LENGTH_SHORT).show();


        } else if (src.equals("ProductDetailsActivity")) {

            assert parcelableProduct != null;
            totalAmount = parcelableProduct.getSellingPrice();
            flag = 1;
            oneProduct.setVisibility(View.VISIBLE);
            productsForBillRecyclerView.setVisibility(View.GONE);
            Locale locale = new Locale("en", "IN");

            Toast.makeText(context, "Billdetails "+totalAmount, Toast.LENGTH_SHORT).show();

            double mrp = parcelableProduct.getMrp();
            double discountPer = parcelableProduct.getDiscount();
            double perProductCost = mrp - ((discountPer / 100) * mrp);

            items = new ArrayList<>();
            items.add(parcelableProduct.getProductName());
            items.add(Double.toString(parcelableProduct.getMrp()));
            items.add(Integer.toString(parcelableProduct.getQty()));
            items.add(Double.toString(parcelableProduct.getDiscount()));
            items.add(Integer.toString(0));
            items.add(Integer.toString(0));
            items.add(Double.toString(parcelableProduct.getSellingPrice()));

            totalAmountTv.setText(String.format(locale, "%,.2f", parcelableProduct.getSellingPrice()));
            Toast.makeText(getActivity(), "Value "+String.format(locale, "%,.2f", parcelableProduct.getSellingPrice()), Toast.LENGTH_SHORT).show();

            productName.setText(parcelableProduct.getProductName());
            sellingPrice.setText(String.format("%s X %d", perProductCost, parcelableProduct.getQty()));

            disc.setText(String.format("%s %%OFF", Double.toString(parcelableProduct.getDiscount())));

            Glide.with(context)
                    .load(parcelableProduct.getProductPic())
                    .centerCrop()
                    .into(productImg);
            createTable(1, 0);


            Toast.makeText(context, "" + src, Toast.LENGTH_SHORT).show();

        }


    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        this.context = context;
    }


    private void getProductWithBill(String userName) {

        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<BillProduct> query = apiInterface.getProductWithBill(userName);

        query.enqueue(new Callback<BillProduct>() {
            @Override
            public void onResponse(Call<BillProduct> call, Response<BillProduct> response) {


                if (response.isSuccessful()) {

                    assert response.body() != null;
                    totalAmount = response.body().getTotal();
                    Locale locale = new Locale("en", "IN");
                    totalAmountTv.setText(String.format(locale, "%,.2f", totalAmount));
                    billList = response.body().getData();

                    createTable(billList.size(), 0);


                }
            }

            @Override
            public void onFailure(Call<BillProduct> call, Throwable t) {


                Toast.makeText(context, "Failed" + t.getCause(), Toast.LENGTH_SHORT).show();

                Log.i("Failed", "onFailure: ffffff" + t.getCause());
            }
        });


    }


    private void getAllCartItems(final String userName) {

        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<Cart> query = apiInterface.viewAllCart(userName);

        query.enqueue(new Callback<Cart>() {
            @Override
            public void onResponse(Call<Cart> call, Response<Cart> response) {
                if (response.isSuccessful()) {

                    assert response.body() != null;
                    if (response.body().getResponse().equals("ok")) {
                        cartItems = response.body().getData();
                        productForBillAdapter = new ProductForBillAdapter(cartItems, context);
                        productsForBillRecyclerView.setAdapter(productForBillAdapter);
                        productForBillAdapter.notifyDataSetChanged();

                    }
                }
            }

            @Override
            public void onFailure(Call<Cart> call, Throwable t) {

            }
        });


    }


    private String generateString() {
        String uuid = UUID.randomUUID().toString();
        return uuid.replaceAll("-", "");
    }


    private void createTable(int size, int couponPer) {
        tableLayout.removeAllViews();
        TableRow tr_head = new TableRow(context);
        tr_head.setId(ViewCompat.generateViewId());
        tr_head.setBackgroundColor(Color.GRAY);
        tr_head.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT
        ));


        //Ist Heading Name

        TextView productName = new TextView(context);
        productName.setId(ViewCompat.generateViewId());


        productName.setText("Item");
        productName.setGravity(Gravity.CENTER);
        productName.setTextColor(Color.BLACK);
        productName.setTextSize(12);
        productName.setPadding(0, 32, 0, 32);
        tr_head.addView(productName);
        //Ist Heading Name///

        //2ND Heading Name
        TextView mrpTxt = new TextView(context);
        mrpTxt.setId(ViewCompat.generateViewId());


        mrpTxt.setText("MRP");
        mrpTxt.setGravity(Gravity.CENTER);
        mrpTxt.setTextColor(Color.BLACK);
        mrpTxt.setTextSize(12);
        mrpTxt.setPadding(0, 32, 0, 32);
        tr_head.addView(mrpTxt);

        //2ND Heading Name//

        //3rd Heading Name
        TextView qtyTxt = new TextView(context);
        qtyTxt.setId(ViewCompat.generateViewId());


        qtyTxt.setText("Qty");
        qtyTxt.setGravity(Gravity.CENTER);
        qtyTxt.setTextColor(Color.BLACK);
        qtyTxt.setTextSize(12);
        qtyTxt.setPadding(0, 32, 0, 32);
        tr_head.addView(qtyTxt);

        //3rd Heading Name//


        //4th Heading Name
        TextView offTxt = new TextView(context);
        offTxt.setId(ViewCompat.generateViewId());


        offTxt.setText("Off");
        offTxt.setGravity(Gravity.CENTER);
        offTxt.setTextColor(Color.BLACK);
        offTxt.setTextSize(12);
        offTxt.setPadding(0, 32, 0, 32);
        tr_head.addView(offTxt);

        //4th Heading Name//


        //5th Heading Name
        TextView scTxt = new TextView(context);
        scTxt.setId(ViewCompat.generateViewId());

        scTxt.setText("SC");
        scTxt.setGravity(Gravity.CENTER);
        scTxt.setTextColor(Color.BLACK);
        scTxt.setTextSize(12);
        scTxt.setPadding(0, 32, 0, 32);
        tr_head.addView(scTxt);

        //5th Heading Name//

        //6th Heading Name
        TextView couponTxt = new TextView(context);
        couponTxt.setId(ViewCompat.generateViewId());

        couponTxt.setText("Coupon");
        couponTxt.setGravity(Gravity.CENTER);
        couponTxt.setTextColor(Color.BLACK);
        couponTxt.setTextSize(12);
        couponTxt.setPadding(0, 32, 0, 32);
        tr_head.addView(couponTxt);

        //6th Heading Name//


        //7th Heading Name
        TextView totalTxt = new TextView(context);
        totalTxt.setId(ViewCompat.generateViewId());
        totalTxt.setText("Total");
        totalTxt.setGravity(Gravity.CENTER);
        totalTxt.setTextColor(Color.BLACK);
        totalTxt.setTextSize(12);
        totalTxt.setPadding(0, 32, 0, 32);
        tr_head.addView(totalTxt);

        //7th Heading Name//

        tableLayout.addView(tr_head);


        TextView[] textArray = new TextView[7];
        TableRow[] tr_heads = new TableRow[size];

        for (int i = 0; i < size; i++) {
            ArrayList<String> rowItems = new ArrayList<>();

            if (flag == 0) {
                Data data = billList.get(i);
                data.setCoupon(couponPer);
                rowItems = data.getItems();
            } else if (flag == 1) {
                rowItems = items;
            }

            tr_heads[i] = new TableRow(context);
            tr_heads[i].setId(ViewCompat.generateViewId());
            tr_heads[i].setBackgroundColor(Color.LTGRAY);
            tr_head.setLayoutParams(new TableRow.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT
            ));

            for (int j = 0; j < 7; j++) {

                textArray[j] = new TextView(context);
                textArray[j].setId(ViewCompat.generateViewId());
                textArray[j].setTextColor(Color.WHITE);
                textArray[j].setText(rowItems.get(j));
                textArray[j].setGravity(Gravity.CENTER);
                textArray[j].setPadding(0, 32, 0, 32);
                tr_heads[i].addView(textArray[j]);

            }
            tableLayout.addView(tr_heads[i], new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT));
        }


    }

    public void getCouponDataFromContext(String percentValue, String value, boolean isSuccess) {

        if (isSuccess) {

            couponContainer.setVisibility(View.GONE);
            double percent = Integer.parseInt(percentValue);
            double flatAmount = Integer.parseInt(value);
            double tempAmount = (percent / 100) * totalAmount;

            bundle = new Bundle();
            bundle.putString("percentValue", percentValue);
            bundle.putString("upToValue", value);
            bundle.putBoolean("isSuccess", isSuccess);

            if (tempAmount < flatAmount) {

                totalAmount = totalAmount - tempAmount;
            } else if (tempAmount > flatAmount) {

                totalAmount = totalAmount - flatAmount;
            }
            Toast.makeText(context, "Congo! Coupon Applied Successfully", Toast.LENGTH_SHORT).show();

            totalAmountTv.setText(String.format("%s", totalAmount));


            if (flag == 0) {
                createTable(billList.size(), (int) percent);
            } else if (flag == 1) {
                items.clear();
                items.add(parcelableProduct.getProductName());
                items.add(Double.toString(parcelableProduct.getMrp()));
                items.add(Integer.toString(parcelableProduct.getQty()));
                items.add(Double.toString(parcelableProduct.getDiscount()));
                items.add(Integer.toString(0));
                items.add((int) percent + "");
                items.add(Double.toString(parcelableProduct.getSellingPrice()));
                createTable(1, (int) percent);
            }
        }
    }

/*

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {

        Toast.makeText(context, "onSaveInstanceState", Toast.LENGTH_SHORT).show();
        outState = bundle;
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Toast.makeText(context, "onActivityCreated", Toast.LENGTH_SHORT).show();
        if (savedInstanceState != null) {
            String percentValue = (String) savedInstanceState.get("percentValue");
            String upToValue = (String) savedInstanceState.get("upToValue");
            boolean isSuccess = savedInstanceState.getBoolean("isSuccess");

            getCouponDataFromContext(percentValue, upToValue, isSuccess);
        }
    }
*/


}
