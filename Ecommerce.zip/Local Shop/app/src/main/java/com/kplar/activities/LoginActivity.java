package com.kplar.activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.kplar.R;
import com.kplar.models.UserResponseData;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;
import com.kplar.utilities.MyReceiver;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {


    ApiInterface myInterface;
    Call<UserResponseData> call1;
    TextView createAccount, fgtpwd, skip;
    Button gobtn;
    EditText mobileEt, pwdEt;
    MyPrefernces myPrefernces;
    private BroadcastReceiver MyReceiver = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        MyReceiver = new MyReceiver();

        broadcastIntent();
        createAccount = findViewById(R.id.createAccount);
        fgtpwd = findViewById(R.id.fgtpwd);
        gobtn = findViewById(R.id.goBtn);
        mobileEt = findViewById(R.id.mobile1);
        pwdEt = findViewById(R.id.pwd1);
        skip = findViewById(R.id.skipId);
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),HomeActivity.class));
            }
        });

        myPrefernces = new MyPrefernces(this);


        gobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                hideKeyBoard();

                String mobile = mobileEt.getText().toString().trim();
                String pwd = pwdEt.getText().toString().trim();

                if (mobile.isEmpty() || pwd.isEmpty()) {

                    Toast.makeText(LoginActivity.this, "Empty Value not Allowed", Toast.LENGTH_SHORT).show();

                } else {

                    myInterface = ApiClient.getApiClient().create(ApiInterface.class);
                    call1 = myInterface.performSignIn(mobile, pwd);

                    call1.enqueue(new Callback<UserResponseData>() {
                        @Override
                        public void onResponse(Call<UserResponseData> call, Response<UserResponseData> response) {

                            assert response.body() != null;
                            if (response.body().getResponse().equals("ok")) {

                                myPrefernces.writeLoginStatus(true);
                                myPrefernces.writeUserName(response.body().getName());
                                myPrefernces.writeUserId(response.body().getId());
                                myPrefernces.writeMobileNo(response.body().getMobile());
                                myPrefernces.writeEmailId(response.body().getEmail());
                                myPrefernces.writeReferCode(response.body().getRefercode());
                                myPrefernces.writeReferCodeDesc(response.body().getDescription());
                                myPrefernces.writeDeviceId(response.body().getMacaddress());
                                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                startActivity(intent);
                                finish();


                            } else if (response.body().getResponse().equals("false")) {

                                Toast.makeText(LoginActivity.this, "Wrong Mobile number or Password", Toast.LENGTH_SHORT).show();


                            }

                        }

                        @Override
                        public void onFailure(Call<UserResponseData> call, Throwable t) {

                        }
                    });


                }

            }
        });


        fgtpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, ForgetPasswordActivity.class);
                startActivity(intent);
            }
        });

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });


    }

    public void hideKeyBoard() {
        View view1 = this.getCurrentFocus();
        if (view1 != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            assert imm != null;
            imm.hideSoftInputFromWindow(view1.getWindowToken(), 0);
        }

    }
    public void broadcastIntent() {
        registerReceiver(MyReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(MyReceiver);
    }
}
