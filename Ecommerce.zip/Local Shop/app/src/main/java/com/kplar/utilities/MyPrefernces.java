package com.kplar.utilities;

import android.content.Context;
import android.content.SharedPreferences;

import com.kplar.R;

import java.util.UUID;

public class MyPrefernces {

    private SharedPreferences mSharedPrefrences;
    private Context context;
    private static String uniqueID = null;
    private static final String PREF_UNIQUE_ID = "PREF_UNIQUE_ID";


    public MyPrefernces(Context context) {
        this.mSharedPrefrences = context.getSharedPreferences(context.getString(R.string.pref_file), Context.MODE_PRIVATE);
        this.context = context;
    }

    public void writeLoginStatus(boolean status) {

        SharedPreferences.Editor editor = mSharedPrefrences.edit();
        editor.putBoolean(context.getString(R.string.pref_login_status), status);
        editor.apply();


    }

    public boolean readLoginStatus() {

        return mSharedPrefrences.getBoolean(context.getString(R.string.pref_login_status), false);
    }

    public void writeUserName(String name) {
        SharedPreferences.Editor editor = mSharedPrefrences.edit();
        editor.putString(context.getString(R.string.pref_user_name), name);
        editor.apply();


    }

    public String readUserName() {

        return mSharedPrefrences.getString(context.getString(R.string.pref_user_name), "Guest");


    }

    public String readUserId() {


        return mSharedPrefrences.getString(context.getString(R.string.pref_user_id), "UserId");
    }

    public void writeEmailId(String email) {
        SharedPreferences.Editor editor = mSharedPrefrences.edit();
        editor.putString(context.getString(R.string.pref_email), email);
        editor.apply();


    }

    public String readEmailId() {


        return mSharedPrefrences.getString(context.getString(R.string.pref_email), "email");
    }


    public void writeUserId(String userId) {

        SharedPreferences.Editor editor = mSharedPrefrences.edit();
        editor.putString(context.getString(R.string.pref_user_id), userId);
        editor.apply();

    }


    public void writeMobileNo(String mobileNo) {

        SharedPreferences.Editor editor = mSharedPrefrences.edit();
        editor.putString(context.getString(R.string.pref_mobile_no), mobileNo);
        editor.apply();

    }

    public String readMobileNo() {

        return mSharedPrefrences.getString(context.getString(R.string.pref_mobile_no), "mobile");

    }

    public void writeReferCode(String referCode) {

        SharedPreferences.Editor editor = mSharedPrefrences.edit();
        editor.putString(context.getString(R.string.refer_code), referCode);
        editor.apply();

    }

    public String readReferCode() {

        return mSharedPrefrences.getString(context.getString(R.string.refer_code), "code");

    }

    public void writeReferCodeDesc(String referCodeDesc) {

        SharedPreferences.Editor editor = mSharedPrefrences.edit();
        editor.putString(context.getString(R.string.refer_code_desc), referCodeDesc);
        editor.apply();

    }

    public String readReferCodeDesc() {

        return mSharedPrefrences.getString(context.getString(R.string.refer_code_desc), "Desc code");

    }


    public void writeDeviceId(String deviceId) {

        SharedPreferences.Editor editor = mSharedPrefrences.edit();
        editor.putString(context.getString(R.string.device_id), deviceId);
        editor.apply();

    }

    public String readDeviceId() {

        return mSharedPrefrences.getString(context.getString(R.string.device_id), "Device Id");

    }


    public synchronized static String saveId(Context context) {
        if (uniqueID == null) {
            SharedPreferences sharedPrefs = context.getSharedPreferences(
                    PREF_UNIQUE_ID, Context.MODE_PRIVATE);
            uniqueID = sharedPrefs.getString(PREF_UNIQUE_ID, null);
            if (uniqueID == null) {
                uniqueID = UUID.randomUUID().toString();
                SharedPreferences.Editor editor = sharedPrefs.edit();
                editor.putString(PREF_UNIQUE_ID, uniqueID);
                editor.apply();
            }
        }
        return uniqueID;
    }
}
