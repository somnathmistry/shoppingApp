package com.kplar.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kplar.R;
import com.kplar.models.todayDealsPackage.Data;

import java.util.List;

public class TodayDealAdapter extends RecyclerView.Adapter<TodayDealAdapter.MyViewHolder> {

    private List<Data> todayDealList;
    private Context context;

    public TodayDealAdapter(List<Data> todayDealList, Context context) {
        this.todayDealList = todayDealList;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_today_deal_layout, parent, false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.productName.setText(todayDealList.get(position).getProductName());
        holder.disPer.setText(String.format("%s%% OFF", todayDealList.get(position).getDiscount()));

        Glide.with(context)
                .load(todayDealList.get(position).getProductImage())
                .centerInside()
                .into(holder.productImg);

    }

    @Override
    public int getItemCount() {
        return 4;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView productName, disPer;
        ImageView productImg;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            productName = itemView.findViewById(R.id.product_name);
            disPer = itemView.findViewById(R.id.discount);
            productImg = itemView.findViewById(R.id.product_img);

        }
    }
}
