package com.kplar.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.kplar.R;
import com.kplar.models.UserResponseData;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.basgeekball.awesomevalidation.ValidationStyle.BASIC;

public class SignUpActivity extends AppCompatActivity {
    EditText userNmaeEt, mobileEt, pwdEt, emailEt;
    Button doneBtn;
    TextView loginTv;
    AwesomeValidation mAwesomeValidation;
    String regexPassword;
    String regexEmail;
    ApiInterface myInterface;
    Call<UserResponseData> call;
    private ProgressDialog progressDialog, progressDialogSign;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        userNmaeEt = findViewById(R.id.mobile1);
        mobileEt = findViewById(R.id.mobile);
        pwdEt = findViewById(R.id.pwd1);
        emailEt = findViewById(R.id.email_id);
        doneBtn = findViewById(R.id.goBtn);
        loginTv = findViewById(R.id.loginbtn);
        progressDialog = new ProgressDialog(this);
        progressDialogSign = new ProgressDialog(this);
        mAwesomeValidation = new AwesomeValidation(BASIC);
        regexPassword = "(?=.*[a-z])(?=.*[A-Z])(?=.*[\\d])(?=.*[~`!@#\\$%\\^&\\*\\(\\)\\-_\\+=\\{\\}\\[\\]\\|\\;:\"<>,./\\?]).{8,}";
        regexEmail = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";


        mAwesomeValidation.addValidation(SignUpActivity.this, R.id.mobile1, "^[A-Za-z0-9_-]{3,15}$", R.string.err_name);
        mAwesomeValidation.addValidation(SignUpActivity.this, R.id.mobile, "^[6-9]\\d{9}$", R.string.err_tel);
        mAwesomeValidation.addValidation(SignUpActivity.this, R.id.pwd1, regexPassword, R.string.password_info);
        mAwesomeValidation.addValidation(SignUpActivity.this, R.id.email_id, regexEmail, R.string.email_error);


        loginTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setTitle("Login..");
                progressDialog.setMessage("Please wait, while we are checking the credentials");
                progressDialog.setCanceledOnTouchOutside(false);
                progressDialog.show();
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                progressDialog.dismiss();

            }
        });


        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyBoard();

                if (mAwesomeValidation.validate()) {
                    String userName = userNmaeEt.getText().toString().trim();
                    String mobile = mobileEt.getText().toString().trim();
                    String pwd = pwdEt.getText().toString().trim();
                    String email = emailEt.getText().toString().trim();


                    //Log.i("Info","Checking1");
                    myInterface = ApiClient.getApiClient().create(ApiInterface.class);
                    call = myInterface.performSignUp(userName, mobile, email, pwd, getDeviceUniqueId());

                    call.enqueue(new Callback<UserResponseData>() {

                        @Override
                        public void onResponse(Call<UserResponseData> call, Response<UserResponseData> response) {


                            assert response.body() != null;
                            if (response.body().getResponse().equals("ok")) {
                                progressDialogSign.setTitle("Registering..");
                                progressDialogSign.setMessage("Please wait, we are registering your account");
                                progressDialogSign.setCanceledOnTouchOutside(false);
                                progressDialogSign.show();
                                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                                startActivity(intent);
                                Toast.makeText(SignUpActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                                finish();
                                progressDialogSign.dismiss();



                            } else if (response.body().getResponse().equals("Exist")) {
                                Toast.makeText(SignUpActivity.this, "Already Exist", Toast.LENGTH_SHORT).show();

                            }

                        }

                        @Override
                        public void onFailure(Call<UserResponseData> call, Throwable t) {
                            t.printStackTrace();

                            Toast.makeText(SignUpActivity.this, "Server Error" + t.toString(), Toast.LENGTH_SHORT).show();


                        }
                    });

                    userNmaeEt.setText("");
                    mobileEt.setText("");
                    pwdEt.setText("");
                    emailEt.setText("");


                }
            }
        });


    }

    public void hideKeyBoard() {
        View view1 = this.getCurrentFocus();
        if (view1 != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            assert imm != null;
            imm.hideSoftInputFromWindow(view1.getWindowToken(), 0);
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        call.cancel();
    }

    private String getDeviceUniqueId() {

        return Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
    }
}
