package com.kplar.fragments;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.kplar.R;
import com.kplar.models.referAndEarnPackage.ReferAndEarn;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.paytm.pgsdk.easypay.listeners.GestureListener.TAG;

public class RedeemReferralCodeDialogFragment extends DialogFragment {
    private Context context;
    private String userName;
    private EditText referralCodeEt;
    private Button applyBtn;


    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater layoutInflater = Objects.requireNonNull(getActivity()).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.redeem_referral_code_dialog_fragment, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(view);


        referralCodeEt = view.findViewById(R.id.referral_code_et);
        applyBtn = view.findViewById(R.id.apply_btn);


        return builder.create();
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        userName = new MyPrefernces(context).readUserName();

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }


    @Override
    public void onStart() {
        super.onStart();


        referralCodeEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                try {
                    if (!TextUtils.isEmpty(s.toString().trim())) {
                        applyBtn.setEnabled(true);

                    } else {

                        referralCodeEt.setError("Empty field");
                        applyBtn.setEnabled(false);
                    }
                } catch (Exception e) {
                    Log.i(TAG, "afterTextChanged: " + e);
                }


            }
        });

        applyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = referralCodeEt.getText().toString().trim();
                if (!code.equals(new MyPrefernces(context).readReferCode()))
                    redeemReferralCode(code);

                else
                    Toast.makeText(context, "Not Valid Operation", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void redeemReferralCode(String code) {
        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Toast.makeText(context, "MAC" + MyPrefernces.saveId(context), Toast.LENGTH_SHORT).show();
        Call<ReferAndEarn> query = apiInterface.redeemReferralCode(userName, code, new MyPrefernces(context).readDeviceId());
        query.enqueue(new Callback<ReferAndEarn>() {
            @Override
            public void onResponse(Call<ReferAndEarn> call, Response<ReferAndEarn> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    if (response.body().getResponse().equals("Done")) {
                        Toast.makeText(context, "Redeem Successfully", Toast.LENGTH_SHORT).show();
                    } else if (response.body().getResponse().equals("Already Done")) {
                        Toast.makeText(context, "Not Valid Operation", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<ReferAndEarn> call, Throwable t) {
                Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();

            }
        });
    }

}