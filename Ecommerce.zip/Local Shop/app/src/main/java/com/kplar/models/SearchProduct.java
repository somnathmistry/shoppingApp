package com.kplar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.kplar.models.productsPackage.ProductsData;

import java.util.List;

public class SearchProduct {
    @Expose
    @SerializedName("response")
    private String response;
    @Expose
    @SerializedName("data")
    private List<SearchProductData> data;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public List<SearchProductData> getData() {
        return data;
    }

    public void setData(List<SearchProductData> data) {
        this.data = data;
    }
}
