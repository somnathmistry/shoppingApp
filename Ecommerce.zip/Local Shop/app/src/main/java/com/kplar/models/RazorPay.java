package com.kplar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RazorPay {

    @SerializedName("orderId")
    @Expose
    String orderId;

    @SerializedName("receipt")
    @Expose
    String receipt;

    @SerializedName("amount")
    @Expose
    String amount;

    @SerializedName("currency")
    @Expose
    String currency;

    @SerializedName("status")
    @Expose
    String status;

    @SerializedName("created_at")
    @Expose
    String created_at;

    public RazorPay(String orderId, String receipt, String amount, String currency, String status, String created_at) {
        this.orderId = orderId;
        this.receipt = receipt;
        this.amount = amount;
        this.currency = currency;
        this.status = status;
        this.created_at = created_at;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getReceipt() {
        return receipt;
    }

    public String getAmount() {
        return amount;
    }

    public String getCurrency() {
        return currency;
    }

    public String getStatus() {
        return status;
    }

    public String getCreated_at() {
        return created_at;
    }
}
