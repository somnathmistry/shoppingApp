package com.kplar.fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.kplar.R;
import com.kplar.activities.ShippingAddressFormActivity;
import com.kplar.models.ViewAddressData;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class AccountFragment extends Fragment {

    private TextView username, errorTv, referCode, referCodeDesc, viewAddress;
    private Context context;
    private ImageButton editBtn, addAddressBtn;
    private EditText nameEt, emailEt, mobileNoEt;
    private Button saveBtn, redeemNowBtn;
    private MyPrefernces myPrefernces;
    private RedeemReferralCodeDialogFragment redeemReferralCodeDialogFragment;
    private ApiInterface apiInterface;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_account, container, false);

        username = view.findViewById(R.id.user_name);
        editBtn = view.findViewById(R.id.edit_btn);
        nameEt = view.findViewById(R.id.name_et);
        mobileNoEt = view.findViewById(R.id.mobile_no_et);
        emailEt = view.findViewById(R.id.email_et);
        errorTv = view.findViewById(R.id.error_tv);
        saveBtn = view.findViewById(R.id.save_btn);
        addAddressBtn = view.findViewById(R.id.add_address_img_btn);
        referCode = view.findViewById(R.id.refer_code);
        redeemNowBtn = view.findViewById(R.id.redeem_now_btn);
        referCodeDesc = view.findViewById(R.id.refer_code_desc);
        viewAddress = view.findViewById(R.id.viewAddressId);

        viewAddressMethod();
        myPrefernces = new MyPrefernces(context);

        referCodeDesc.setText(String.format("Share this Code with Friends you and your will Earn %s", myPrefernces.readReferCodeDesc()));
        referCode.setText(String.format("Your referral code is : %s", myPrefernces.readReferCode()));

        return view;
    }

    private void viewAddressMethod() {
        apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<ViewAddressData> addressCall = apiInterface.getAddress("Sam");
        addressCall.enqueue(new Callback<ViewAddressData>() {
            @Override
            public void onResponse(Call<ViewAddressData> call, Response<ViewAddressData> response) {
//                if (response.isSuccessful()){
                    response.body().getAddress();
                    Toast.makeText(context, "Add "+response.body().getAddress(), Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "onResponse: "+response.body().getAddress());
                    viewAddress.setText(response.body().getAddress());

//                }
            }

            @Override
            public void onFailure(Call<ViewAddressData> call, Throwable t) {

            }
        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        username.setText(myPrefernces.readUserName());
        mobileNoEt.setText(myPrefernces.readMobileNo());
        emailEt.setText(myPrefernces.readEmailId());
        nameEt.setText(myPrefernces.readUserName());

        redeemNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                redeemReferralCodeDialogFragment = new RedeemReferralCodeDialogFragment();
                redeemReferralCodeDialogFragment.show(Objects.requireNonNull(getActivity()).getSupportFragmentManager(), "Code Referral Dialog");
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();


        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mobileNoEt.setAlpha(1);
                mobileNoEt.setEnabled(true);
                mobileNoEt.setBackgroundColor(Color.parseColor("#ffffff"));


                emailEt.setAlpha(1);
                emailEt.setEnabled(true);
                emailEt.setBackgroundColor(Color.parseColor("#ffffff"));
                // emailEt.setHorizontallyScrolling(true);

                nameEt.setAlpha(1);
                nameEt.setEnabled(true);
                nameEt.setBackgroundColor(Color.parseColor("#ffffff"));
                nameEt.requestFocus();

                editBtn.setVisibility(View.GONE);
                saveBtn.setVisibility(View.VISIBLE);

            }
        });


        nameEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if (!TextUtils.isEmpty(s.toString())) {

                } else {


                }

            }
        });

        emailEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        mobileNoEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        addAddressBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ShippingAddressFormActivity.class);
                context.startActivity(intent);
            }
        });
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;

    }
}
