package com.kplar.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.kplar.R;
import com.kplar.SearchActivity;
import com.kplar.adapters.FeaturedProductAdapter;
import com.kplar.adapters.NewProductAdapter;
import com.kplar.adapters.OfferSliderAdapter;
import com.kplar.adapters.RecentViewAdapter;
import com.kplar.adapters.SponsoredProductsAdapter;
import com.kplar.adapters.TodayDealAdapter;
import com.kplar.adapters.TopCategoryAdapter;
import com.kplar.models.OfferSliders;
import com.kplar.models.featureProductsPackage.FeaturedProduct;
import com.kplar.models.newProductsPackage.Data;
import com.kplar.models.newProductsPackage.NewProduct;
import com.kplar.models.recentViewPackage.Product;
import com.kplar.models.recentViewPackage.RecentView;
import com.kplar.models.sponsoredProductsPackage.SponsoredProduct;
import com.kplar.models.todayDealsPackage.TodayDeal;
import com.kplar.models.topCategoriesPackage.TopCategorySlider;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.GridSpacingItemDecoration;
import com.kplar.utilities.MyPrefernces;

import java.util.List;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HomeFragment extends Fragment {


    TodayDealAdapter todayDealAdapter;
    ProgressBar homeProgressBar;
    private ViewPager myViewPager;
    private List<OfferSliders> offerImages;
    private List<Product> productList;
    private Timer timer;
    private ConstraintLayout recentContainer, newProductContainer, sponsoredProductContainer, featuredProductsContainer, todayDealContainer;
    private SponsoredProductsAdapter sponsoredProductsAdapter;
    private RecyclerView newProductsRecyclerView, featuredProductRv;
    private NewProductAdapter newProductAdapter;
    private List<Data> newProductList;
    private Context context;
    private RecyclerView recentViewRecyclerView, sponsoredProductRv;
    private RecentViewAdapter recentViewAdapter;

    private OfferSliderAdapter offerSliderAdapter;
    private ApiInterface myInterface, sliderInterface;
    private RecyclerView myRecycler, todayDealsRv;
    private TopCategoryAdapter myAdapter;
    private List<TopCategorySlider> imagelist;
    private String userName;
    private EditText location, searchEdit;
    private Button viewAllBn;
    private LinearLayout catagoryBn;


    private MyPrefernces myPrefernces;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        myRecycler = view.findViewById(R.id.recyclerView);
        myViewPager = view.findViewById(R.id.viewPager);
        recentContainer = view.findViewById(R.id.recent_container);
        newProductContainer = view.findViewById(R.id.new_products_container);
        todayDealsRv = view.findViewById(R.id.today_deal_rv);
        todayDealContainer = view.findViewById(R.id.today_deal_container);
        recentViewRecyclerView = view.findViewById(R.id.recent_view_recycler_view);
        viewAllBn = view.findViewById(R.id.button5);

        newProductsRecyclerView = view.findViewById(R.id.new_product_recycler_view);

        sponsoredProductRv = view.findViewById(R.id.sponsored_products_rv);
        sponsoredProductContainer = view.findViewById(R.id.sponsored_products_container);
        searchEdit = view.findViewById(R.id.searchId);

        featuredProductRv = view.findViewById(R.id.featured_product_rv);
        featuredProductsContainer = view.findViewById(R.id.featured_products_container);

        homeProgressBar = view.findViewById(R.id.home_progress_bar);


        myPrefernces = new MyPrefernces(Objects.requireNonNull(getActivity()));


        viewAllBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), SearchActivity.class));
            }
        });
        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Objects.requireNonNull(((AppCompatActivity) Objects.requireNonNull(getActivity())).getSupportActionBar()).setTitle("MyFreeShopping");

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        myRecycler.setLayoutManager(linearLayoutManager);
        myRecycler.setHasFixedSize(true);


        LinearLayoutManager recentViewLinearLayoutManager = new LinearLayoutManager(getActivity());
        recentViewLinearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recentViewRecyclerView.setLayoutManager(recentViewLinearLayoutManager);
        recentViewRecyclerView.setHasFixedSize(true);


        GridLayoutManager newProductGLM = new GridLayoutManager(getActivity(), 2);
        newProductGLM.setOrientation(LinearLayoutManager.VERTICAL);
        newProductsRecyclerView.setLayoutManager(newProductGLM);
        newProductsRecyclerView.setHasFixedSize(true);


        int spanCount = 2;
        int spacing = 48;
        boolean includeEdge = true;
        newProductsRecyclerView.addItemDecoration(new GridSpacingItemDecoration(spanCount, spacing, includeEdge));


        GridLayoutManager staggeredGridLayoutManager = new GridLayoutManager(getActivity(), 2);
        sponsoredProductRv.setLayoutManager(staggeredGridLayoutManager);
        sponsoredProductRv.setHasFixedSize(true);

        int spanCounts = 2;
        int spacings = 48;
        boolean includeEdges = true;
        sponsoredProductRv.addItemDecoration(new GridSpacingItemDecoration(spanCounts, spacings, includeEdges));


        GridLayoutManager featuredProductGLM = new GridLayoutManager(getActivity(), 2);
        featuredProductGLM.setOrientation(LinearLayoutManager.VERTICAL);
        featuredProductRv.setLayoutManager(featuredProductGLM);
        featuredProductRv.setHasFixedSize(true);


        GridLayoutManager todayDealsGLM = new GridLayoutManager(getActivity(), 2);
        todayDealsGLM.setOrientation(LinearLayoutManager.VERTICAL);
        todayDealsRv.setLayoutManager(todayDealsGLM);
        todayDealsRv.setHasFixedSize(true);


        userName = myPrefernces.readUserName();


        getImagesForTopCategory();
        getImagesForSlider();

    }


    //Getting Retrofit client and making request for images url of top category
    private void getImagesForTopCategory() {

        myInterface = ApiClient.getApiClient().create(ApiInterface.class);
        homeProgressBar.setVisibility(View.VISIBLE);
        Call<List<TopCategorySlider>> query = myInterface.getSliderItems();

        query.enqueue(new Callback<List<TopCategorySlider>>() {
            @Override
            public void onResponse(Call<List<TopCategorySlider>> call, Response<List<TopCategorySlider>> response) {
                homeProgressBar.setVisibility(View.GONE);

                if (response.isSuccessful()) {


                    imagelist = response.body();
                    Log.i("My Result", "onResponse1: " + response.body());
                    //Toast.makeText(getContext(), "Inside Response"+imagelist, Toast.LENGTH_SHORT).show();
                    myAdapter = new TopCategoryAdapter(imagelist, getActivity());
                    myRecycler.setAdapter(myAdapter);
                    myAdapter.notifyDataSetChanged();


                }

            }

            @Override
            public void onFailure(Call<List<TopCategorySlider>> call, Throwable t) {
                homeProgressBar.setVisibility(View.GONE);

            }
        });


    }


    private void getImagesForSlider() {

        sliderInterface = ApiClient.getApiClient().create(ApiInterface.class);
        homeProgressBar.setVisibility(View.VISIBLE);
        Call<List<OfferSliders>> query = sliderInterface.getSlider();
        query.enqueue(new Callback<List<OfferSliders>>() {
            @Override
            public void onResponse(Call<List<OfferSliders>> call, Response<List<OfferSliders>> response) {

                homeProgressBar.setVisibility(View.GONE);
                if (response.isSuccessful()) {

                    offerImages = response.body();
                    offerSliderAdapter = new OfferSliderAdapter(offerImages, getActivity());
                    myViewPager.setAdapter(offerSliderAdapter);
                    createSlideShow();


                }
            }

            @Override
            public void onFailure(Call<List<OfferSliders>> call, Throwable t) {
                Toast.makeText(context, "Failed" + t.getMessage(), Toast.LENGTH_LONG).show();
                Log.i("eeece", "onFailure: " + t.getMessage());
                homeProgressBar.setVisibility(View.GONE);

            }
        });


    }


    @Override
    public void onStart() {
        super.onStart();
        viewRecentProducts();
        getNewProductList();
        getSponsoredProducts();
        getFeaturedProducts();
        getTodayDeals();
    }


    // slide show for offerSlider
    private void createSlideShow() {

        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                int currentPosition = myViewPager.getCurrentItem();
                if (currentPosition == offerImages.size() - 1) {
                    currentPosition = -1;
                }
                myViewPager.setCurrentItem(++currentPosition, true);
            }
        };
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, 2000, 5000);


    }


    private void viewRecentProducts() {
        myInterface = ApiClient.getApiClient().create(ApiInterface.class);
        homeProgressBar.setVisibility(View.VISIBLE);
        Call<RecentView> query = myInterface.viewRecentProducts(userName);

        query.enqueue(new Callback<RecentView>() {
            @Override
            public void onResponse(Call<RecentView> call, Response<RecentView> response) {
                homeProgressBar.setVisibility(View.GONE);

                assert response.body() != null;
                if (response.isSuccessful() && response.body().getResponse().equals("ok")) {

                    recentContainer.setVisibility(View.VISIBLE);

                    productList = response.body().getProduct();
                    recentViewAdapter = new RecentViewAdapter(productList, getActivity());
                    recentViewRecyclerView.setAdapter(recentViewAdapter);
                    recentViewAdapter.notifyDataSetChanged();
                } else {

                    recentContainer.setVisibility(View.GONE);

                }
            }

            @Override
            public void onFailure(Call<RecentView> call, Throwable t) {
                recentContainer.setVisibility(View.GONE);
                homeProgressBar.setVisibility(View.GONE);
            }
        });

    }


    private void getNewProductList() {

        myInterface = ApiClient.getApiClient().create(ApiInterface.class);
        homeProgressBar.setVisibility(View.VISIBLE);
        Call<NewProduct> query = myInterface.getNewProducts();

        query.enqueue(new Callback<NewProduct>() {
            @Override
            public void onResponse(Call<NewProduct> call, Response<NewProduct> response) {
                homeProgressBar.setVisibility(View.GONE);

                try {


                    if (response.isSuccessful()) {

                        assert response.body() != null;
                        if (response.body().getResponse().equals("ok")) {

                            newProductContainer.setVisibility(View.VISIBLE);


                            newProductList = response.body().getData();
                            newProductAdapter = new NewProductAdapter(newProductList, getActivity());

                            newProductsRecyclerView.setAdapter(newProductAdapter);
                            newProductAdapter.notifyDataSetChanged();


                        } else {

                            newProductContainer.setVisibility(View.GONE);
                        }

                    }
                } catch (NullPointerException e) {
                    Toast.makeText(getActivity(), "" + e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call<NewProduct> call, Throwable t) {
                newProductContainer.setVisibility(View.GONE);
                homeProgressBar.setVisibility(View.GONE);

            }
        });


    }


    private void getSponsoredProducts() {
        myInterface = ApiClient.getApiClient().create(ApiInterface.class);
        homeProgressBar.setVisibility(View.VISIBLE);
        Call<SponsoredProduct> query = myInterface.getSponsoredProducts();

        query.enqueue(new Callback<SponsoredProduct>() {
            @Override
            public void onResponse(Call<SponsoredProduct> call, Response<SponsoredProduct> response) {
                homeProgressBar.setVisibility(View.GONE);


                if (response.isSuccessful()) {

                    sponsoredProductContainer.setVisibility(View.VISIBLE);
                    List<com.kplar.models.sponsoredProductsPackage.Data> sponsoredProductList;
                    assert response.body() != null;
                    sponsoredProductList = response.body().getData();
                    sponsoredProductsAdapter = new SponsoredProductsAdapter(sponsoredProductList, getActivity());
                    sponsoredProductRv.setAdapter(sponsoredProductsAdapter);
                    sponsoredProductsAdapter.notifyDataSetChanged();
                } else {

                    sponsoredProductContainer.setVisibility(View.GONE);

                }
            }

            @Override
            public void onFailure(Call<SponsoredProduct> call, Throwable t) {
                sponsoredProductContainer.setVisibility(View.GONE);
                homeProgressBar.setVisibility(View.GONE);
            }
        });

    }


    private void getFeaturedProducts() {
        myInterface = ApiClient.getApiClient().create(ApiInterface.class);
        homeProgressBar.setVisibility(View.VISIBLE);
        Call<FeaturedProduct> query = myInterface.getFeaturedProducts();

        query.enqueue(new Callback<FeaturedProduct>() {
            @Override
            public void onResponse(Call<FeaturedProduct> call, Response<FeaturedProduct> response) {
                homeProgressBar.setVisibility(View.GONE);

                assert response.body() != null;

                if (response.isSuccessful() && response.body().getResponse().equals("ok")) {

                    featuredProductsContainer.setVisibility(View.VISIBLE);

                    List<com.kplar.models.featureProductsPackage.Data> featuredProductsList;


                    featuredProductsList = response.body().getData();

                    FeaturedProductAdapter featuredProductAdapter = new FeaturedProductAdapter(featuredProductsList, getActivity());
                    featuredProductRv.setAdapter(featuredProductAdapter);
                    featuredProductAdapter.notifyDataSetChanged();
                } else {

                    featuredProductsContainer.setVisibility(View.GONE);
                }

            }

            @Override
            public void onFailure(Call<FeaturedProduct> call, Throwable t) {
                featuredProductsContainer.setVisibility(View.GONE);
                homeProgressBar.setVisibility(View.GONE);
            }
        });

    }


    private void getTodayDeals() {
        myInterface = ApiClient.getApiClient().create(ApiInterface.class);
        homeProgressBar.setVisibility(View.VISIBLE);
        Call<TodayDeal> query = myInterface.getTodayDealProducts();
        query.enqueue(new Callback<TodayDeal>() {
            @Override
            public void onResponse(Call<TodayDeal> call, Response<TodayDeal> response) {
                homeProgressBar.setVisibility(View.GONE);

                assert response.body() != null;

                Toast.makeText(getActivity(), "Doneee" + response.code(), Toast.LENGTH_SHORT).show();

                if (response.isSuccessful() && response.body().getResponse().equals("ok")) {
                    todayDealContainer.setVisibility(View.VISIBLE);

                    List<com.kplar.models.todayDealsPackage.Data> todayDealList;
                    todayDealList = response.body().getData();
                    todayDealAdapter = new TodayDealAdapter(todayDealList, getActivity());
                    todayDealsRv.setAdapter(todayDealAdapter);
                    todayDealAdapter.notifyDataSetChanged();

                }
            }

            @Override
            public void onFailure(Call<TodayDeal> call, Throwable t) {
                homeProgressBar.setVisibility(View.GONE);
                todayDealContainer.setVisibility(View.GONE);

                Toast.makeText(getActivity(), "" + t.getCause(), Toast.LENGTH_SHORT).show();
            }
        });


    }


    @Override
    public void onDestroyView() {
        if (timer != null) {
            timer.cancel();
        }


        super.onDestroyView();
    }
}
