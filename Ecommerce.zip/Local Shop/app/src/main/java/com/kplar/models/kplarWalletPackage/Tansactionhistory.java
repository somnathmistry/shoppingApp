package com.kplar.models.kplarWalletPackage;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Tansactionhistory {
    @Expose
    @SerializedName("date")
    private String date;
    @Expose
    @SerializedName("transactionid")
    private String transactionid;
    @Expose
    @SerializedName("type")
    private String type;
    @Expose
    @SerializedName("amount")
    private String amount;
    @Expose
    @SerializedName("username")
    private String username;
    @Expose
    @SerializedName("order_id")
    private String orderId;
    @Expose
    @SerializedName("id")
    private String id;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTransactionid() {
        return transactionid;
    }

    public void setTransactionid(String transactionid) {
        this.transactionid = transactionid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
