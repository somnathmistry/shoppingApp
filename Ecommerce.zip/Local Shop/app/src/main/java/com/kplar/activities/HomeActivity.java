package com.kplar.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.kplar.R;
import com.kplar.SearchActivity;
import com.kplar.fragments.AccountFragment;
import com.kplar.fragments.CategoryFragment;
import com.kplar.fragments.HomeFragment;
import com.kplar.fragments.OrderFragment;
import com.kplar.utilities.MyPrefernces;

import java.util.Objects;

import hotchemi.android.rate.AppRate;

public class HomeActivity extends AppCompatActivity {


    TextView categoryBtn, starredBtn, cartBtn, offersBtn, myAccount, helpBtn, sellerBtn, ordersBtn, giftCardBtn, feedbackBn, termsBn, pricacyBn;
    TextView emailid, number;
    TextView cart_btn;
    HomeFragment homeFragment;
    CategoryFragment categoryFragment;
    OrderFragment orderFragment;
    AccountFragment accountFragment;
    FragmentManager fragmentManager;
    Button logoutBtn;
    MyPrefernces myPrefernces;
    DrawerLayout myDrawer;
    BottomNavigationView myHomeBottomNav;
    Toolbar myHomeToolBar;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ActionBarDrawerToggle toggle;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer_layout);
        myHomeToolBar = findViewById(R.id.homeToolbar);

        setSupportActionBar(myHomeToolBar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayShowTitleEnabled(false);

        categoryBtn = findViewById(R.id.categorybtn);
        logoutBtn = findViewById(R.id.logoutBtn);
        starredBtn = findViewById(R.id.starred_btn);
        cartBtn = findViewById(R.id.cart_btn);
        offersBtn = findViewById(R.id.offers_zone);
        //kplarWallet = findViewById(R.id.kplar_wallet);
        myAccount = findViewById(R.id.my_account_iv);
        helpBtn = findViewById(R.id.help_btn);
        sellerBtn = findViewById(R.id.seller_btn);
        ordersBtn = findViewById(R.id.order_imgv);
        giftCardBtn = findViewById(R.id.gift_card);
        //contactBn = findViewById(R.id.contactUsId);
        feedbackBn = findViewById(R.id.feedbackId);
        termsBn = findViewById(R.id.termsId);
        pricacyBn = findViewById(R.id.privacyId);
        myPrefernces = new MyPrefernces(this);

        emailid = findViewById(R.id.emailIdnav);
        number = findViewById(R.id.numberIdnav);

        emailid.setText(myPrefernces.readEmailId());
        number.setText(myPrefernces.readMobileNo());

        //myHomeToolBar.setTitle("");
        myHomeToolBar.setNavigationIcon(R.drawable.nav);
        myHomeToolBar.setElevation(0);
        //myHomeToolBar.setTitleTextColor(getResources().getColor(R.color.white_color));
        //myHomeToolBar.setTitleTextAppearance(this, R.style.myFont);
        //myHomeToolBar.setLogo(R.drawable.logosvgmin);
        myHomeBottomNav = findViewById(R.id.homeBottomNav);
        myHomeBottomNav.setBackgroundColor(Color.parseColor("#ffffff"));
        myPrefernces = new MyPrefernces(this);

        homeFragment = new HomeFragment();
        categoryFragment = new CategoryFragment();
        accountFragment = new AccountFragment();
        orderFragment = new OrderFragment();

        myDrawer = findViewById(R.id.drawerLayout);

        setFragment(homeFragment, "home");

        categoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDrawer.closeDrawer(GravityCompat.START);
                setFragment(categoryFragment, "category");
                myHomeBottomNav.setSelectedItemId(R.id.category);
            }
        });

        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                myPrefernces.writeLoginStatus(false);
                //myDrawer.closeDrawer(GravityCompat.START);
                Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        starredBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDrawer.closeDrawer(GravityCompat.START);
                Intent intent = new Intent(HomeActivity.this, StarredActivity.class);
                startActivity(intent);
            }
        });

        cartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, CartActivity.class);
                startActivity(intent);
                myDrawer.closeDrawer(GravityCompat.START);
            }
        });

        offersBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, OffersActivity.class);
                startActivity(intent);
                myDrawer.closeDrawer(GravityCompat.START);
            }
        });
//        kplarWallet.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(HomeActivity.this, KplarWalletActivity.class);
//                startActivity(intent);
//                myDrawer.closeDrawer(GravityCompat.START);
//            }
//        });

        myAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                myDrawer.closeDrawer(GravityCompat.START);
                setFragment(accountFragment, "account");
                myHomeBottomNav.setSelectedItemId(R.id.account);
            }
        });

        helpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, HelpActivity.class);
                startActivity(intent);
                myDrawer.closeDrawer(GravityCompat.START);
            }
        });

        sellerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, SellerActivity.class);
                startActivity(intent);
                myDrawer.closeDrawer(GravityCompat.START);
            }
        });

        ordersBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDrawer.closeDrawer(GravityCompat.START);
                setFragment(orderFragment, "order");
                myHomeBottomNav.setSelectedItemId(R.id.orders);
            }
        });

        giftCardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDrawer.closeDrawer(GravityCompat.START);
                Intent intent = new Intent(HomeActivity.this, GiftCardActivity.class);
                startActivity(intent);
            }
        });

        feedbackBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppRate.with(HomeActivity.this)
                        .setInstallDays(1)
                        .setLaunchTimes(3)
                        .setRemindInterval(2)
                        .monitor();
                AppRate.showRateDialogIfMeetsConditions(HomeActivity.this);
                AppRate.with(HomeActivity.this).clearAgreeShowDialog();
                AppRate.with(HomeActivity.this).showRateDialog(HomeActivity.this);
                myDrawer.closeDrawers();


            }
        });
        termsBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), TermsActivity.class));
                myDrawer.closeDrawers();
            }
        });
        pricacyBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), PrivacyActivity.class));
            }
        });


        // click listener for navigation icon of toolbar
        myHomeToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDrawer.openDrawer(GravityCompat.START);

            }
        });


        myHomeBottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {


                switch (menuItem.getItemId()) {

                    case R.id.home:
                        setFragment(homeFragment, "home");
                        break;

                    case R.id.category:
                        setFragment(categoryFragment, "category");
                        break;

                    case R.id.account:
                        setFragment(accountFragment, "account");
                        break;

                    case R.id.orders:
                        setFragment(orderFragment, "order");
                        break;

                }
                return true;

            }
        });
    }

    private void setFragment(Fragment fragment, String fgrName) {
        if (fragment != null) {
            fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.homeContainer, fragment, fgrName);
            fragmentTransaction.addToBackStack("OP" + fgrName);
            fragmentTransaction.commit();
        }

    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.search:
                startActivity(new Intent(getApplicationContext(), SearchActivity.class));
                return true;

            case R.id.notification:
                Intent intent = new Intent(HomeActivity.this, NotificationActivity.class);
                startActivity(intent);
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        HomeFragment homeFgr = (HomeFragment) getSupportFragmentManager().findFragmentByTag("home");
        CategoryFragment catFgr = (CategoryFragment) getSupportFragmentManager().findFragmentByTag("category");
        AccountFragment acnFgr = (AccountFragment) getSupportFragmentManager().findFragmentByTag("account");
        OrderFragment odrFgr = (OrderFragment) getSupportFragmentManager().findFragmentByTag("order");

        if (homeFgr != null && homeFgr.isVisible()) {
            myHomeBottomNav.setSelectedItemId(R.id.home);

        } else if (catFgr != null && catFgr.isVisible()) {
            myHomeBottomNav.setSelectedItemId(R.id.category);

        } else if (acnFgr != null && acnFgr.isVisible()) {
            myHomeBottomNav.setSelectedItemId(R.id.account);

        } else if (odrFgr != null && odrFgr.isVisible()) {
            myHomeBottomNav.setSelectedItemId(R.id.orders);
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();

        if (homeFragment != null && homeFragment.isVisible()) {
            myHomeBottomNav.setSelectedItemId(R.id.home);
            super.onBackPressed();
        } else if (categoryFragment != null && categoryFragment.isVisible()) {
            myHomeBottomNav.setSelectedItemId(R.id.category);
            super.onBackPressed();
        } else if (accountFragment != null && accountFragment.isVisible()) {
            myHomeBottomNav.setSelectedItemId(R.id.account);
            super.onBackPressed();
        } else if (orderFragment != null && orderFragment.isVisible()) {
            myHomeBottomNav.setSelectedItemId(R.id.orders);
            super.onBackPressed();
        } else {
            finish();
        }


    }


}
