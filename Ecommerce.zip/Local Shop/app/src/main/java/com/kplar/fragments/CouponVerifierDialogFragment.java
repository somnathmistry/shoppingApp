package com.kplar.fragments;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.kplar.R;
import com.kplar.models.couponPackage.Coupon;
import com.kplar.utilities.ApiClient;
import com.kplar.utilities.ApiInterface;
import com.kplar.utilities.MyPrefernces;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.paytm.pgsdk.easypay.listeners.GestureListener.TAG;

public class CouponVerifierDialogFragment extends DialogFragment {

    OnCouponVerifiedListener onCouponVerifiedListener;
    private Context context;
    private EditText couponEt;
    private Button applyBtn;
    String userName;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater layoutInflater = Objects.requireNonNull(getActivity()).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.fragment_coupon_verifier_dialog, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(view);

        couponEt = view.findViewById(R.id.coupon_et);
        applyBtn = view.findViewById(R.id.apply_btn);


        return builder.create();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        onCouponVerifiedListener = (OnCouponVerifiedListener) context;

        userName = new MyPrefernces(context).readUserName();

    }

    @Override
    public void onStart() {
        super.onStart();


        couponEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                try {
                    if (!TextUtils.isEmpty(s.toString().trim())) {
                        applyBtn.setEnabled(true);

                    } else {

                        couponEt.setError("Empty field");
                        applyBtn.setEnabled(false);
                    }
                } catch (Exception e) {
                    Log.i(TAG, "afterTextChanged: " + e);
                }


            }
        });

        applyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String coupon = couponEt.getText().toString().trim();
                verifyCouponCode(coupon);

            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }


    private void verifyCouponCode(String couponCode) {
        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<Coupon> query = apiInterface.getCouponCode(userName, couponCode);

        query.enqueue(new Callback<Coupon>() {
            @Override
            public void onResponse(Call<Coupon> call, Response<Coupon> response) {
                if (response.isSuccessful()) {

                    assert response.body() != null;
                    if (response.body().getResponse().equals("Available Coupon Code")) {
                        onCouponVerifiedListener.couponData(response.body().getData().getValue(), response.body().getData().getUpto(), true);
                        dismiss();
                    } else if (response.body().getResponse().equals("Invalid Coupon Code")) {
                        couponEt.setError("Invalid Coupon Code");
                    }
                }

            }

            @Override
            public void onFailure(Call<Coupon> call, Throwable t) {
                Toast.makeText(context, "Failed" + t.getCause(), Toast.LENGTH_SHORT).show();

            }
        });


    }


    public interface OnCouponVerifiedListener {
        void couponData(String percentValue, String upToValue, boolean isSuccess);
    }
}
